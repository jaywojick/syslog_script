"""Combine syslog fill-rate measurements and setup snapshots into assessment reports.

Also compares the combined per-minute fill rate of all servers with the shared
Cribl ingestion rate. Local files only; no network access.
"""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import stat

from syslog_evidence import parse_iso_datetime

DEFAULT_CRIBL_RATE_MB_SEC = 2.4  # Customer-supplied rate shared by all servers.
MINUTE_COVERAGE_SECONDS = 30     # A server "covers" a minute when observed for at least this long.


# ---------------------------------------------------------------- input files

def read_report_json(path):
    """Bounded regular-file read; reports are data, never executable input."""
    limit = 64 * 1024 * 1024
    fd = os.open(str(path), os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError('Report must be a regular file no larger than 64 MiB')
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('Report exceeds 64 MiB review limit')
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError('Report JSON must be an object')
    return data


def discover_reports(root, output_dir=None):
    """Find JSON files recursively without following directory/file symlinks."""
    root = Path(root).expanduser().absolute()
    output_dir = Path(output_dir).expanduser().absolute() if output_dir else None
    found, errors = [], []

    def onerror(exc):
        errors.append({'file': str(exc.filename), 'error': str(exc)})
    for current, directories, filenames in os.walk(root, followlinks=False, onerror=onerror):
        current = Path(current)
        for name in list(directories):
            path = current/name
            if output_dir is not None and output_dir != root and path.resolve() == output_dir.resolve():
                directories.remove(name)
            elif path.is_symlink():
                directories.remove(name)
                errors.append({'file': str(path), 'error': 'Symlink directory skipped; input coverage may be incomplete.'})
        for name in sorted(filenames):
            if not name.lower().endswith('.json') or not name.startswith('syslog_'):
                continue
            path = current/name
            try:
                if not stat.S_ISREG(path.lstat().st_mode):
                    raise ValueError('Non-regular/symlink JSON input skipped.')
                found.append(path)
            except (OSError, ValueError) as exc:
                errors.append({'file': str(path), 'error': str(exc)})
    return sorted(found), errors


# ---------------------------------------------------------------- time series

def epoch(value):
    try:
        moment = parse_iso_datetime(str(value))
    except ValueError:
        return None
    return moment.timestamp() if moment.tzinfo else None


def apportion(intervals, origin, width):
    """Spread each interval's growth over fixed buckets of `width` seconds.

    origin is the epoch (or 0 for elapsed time) that interval elapsed_seconds
    are relative to. Returns {bucket_start: [growth_bytes, observed_seconds]}.
    """
    buckets = {}
    for interval in intervals:
        end = float(interval.get('elapsed_seconds', 0))
        duration = float(interval.get('interval_seconds', 0))
        if duration <= 0:
            continue
        growth = float(interval.get('same_inode_growth_bytes', 0))
        pos, stop_at = origin + max(0.0, end - duration), origin + end
        while pos < stop_at:
            bucket = int(pos // width) * width
            stop = min(stop_at, bucket + width)
            if stop <= pos:
                break
            row = buckets.setdefault(bucket, [0.0, 0.0])
            row[0] += growth * (stop - pos) / duration
            row[1] += stop - pos
            pos = stop
    return buckets


def hourly_intervals(window):
    """Elapsed one-hour blocks; boundary-crossing deltas are apportioned."""
    rows = []
    for start, (growth, seconds) in sorted(apportion(window.get('intervals', []), 0, 3600).items()):
        rows.append({'elapsed_hour': int(start // 3600) + 1, 'observed_seconds': seconds, 'observed_growth_bytes': growth,
                     'average_MB_per_second': growth / seconds / 1e6 if seconds else None})
    return rows


def minute_series(windows):
    """Per-UTC-minute growth for a server: sorted [[minute_epoch, growth_bytes, observed_seconds], ...]."""
    merged = {}
    for window in windows:
        origin = epoch(window.get('started_utc'))
        if origin is None:
            continue
        for minute, (growth, seconds) in apportion(window.get('intervals', []), origin, 60).items():
            row = merged.setdefault(int(minute), [0.0, 0.0])
            row[0] += growth
            row[1] += seconds
    return [[minute, round(growth, 1), round(seconds, 3)] for minute, (growth, seconds) in sorted(merged.items())]


def utc_text(minute):
    return datetime.fromtimestamp(minute, timezone.utc).strftime('%Y-%m-%d %H:%M UTC')


def fleet_capacity(servers, rate):
    """Combined fill rate of all servers per UTC minute versus the shared Cribl rate."""
    series = {}
    for server in servers:
        rows = {int(m): (g, s) for m, g, s in server.get('minute_series') or [] if s >= MINUTE_COVERAGE_SECONDS}
        if rows:
            series[server['hostname'] + ' ' + server['directory']] = rows
    result = {'cribl_rate_MB_per_second_shared': rate, 'servers_with_measurements': len(series),
              'servers_without_measurements': sorted(s['hostname'] + ' ' + s['directory'] for s in servers
                                                     if s['hostname'] + ' ' + s['directory'] not in series),
              'minute_coverage_rule': 'A server counts for a minute when measured for at least %d seconds of it.' % MINUTE_COVERAGE_SECONDS,
              'limitations': ['Rates are per-minute averages; shorter bursts within a minute are not visible.',
                              'Only minutes measured on every included server are combined; run all servers over the same period.',
                              'Growth is a lower bound: writes hidden by rotation, truncation or deletion between scans are not counted.',
                              'The shared rate is customer-supplied; confirm the actual sustainable Cribl ingestion rate in a pilot.']}
    if not series:
        result.update(status='NO_MEASUREMENTS', verdict='No per-minute measurements are available.')
        return result
    every = set.intersection(*(set(rows) for rows in series.values()))
    union = set.union(*(set(rows) for rows in series.values()))
    result.update(minutes_combined=len(every), minutes_partial_coverage=len(union - every),
                  first_minute_utc=utc_text(min(union)), last_minute_utc=utc_text(max(union)))
    if not every:
        result.update(status='NO_COMMON_COVERAGE',
                      verdict='The servers were not measured over the same minutes, so their rates cannot be combined. Re-run with the same start time.')
        return result
    combined = []
    for minute in sorted(every):
        per = {name: rows[minute][0] / rows[minute][1] / 1e6 for name, rows in series.items()}
        combined.append((minute, sum(per.values()), per))
    peak_minute, peak, peak_parts = max(combined, key=lambda row: row[1])
    above = [minute for minute, value, _ in combined if value > rate]
    longest, longest_start, run, run_start, previous = 0, None, 0, None, None
    for minute in above:
        if previous is not None and minute - previous == 60:
            run += 1
        else:
            run, run_start = 1, minute
        if run > longest:
            longest, longest_start = run, run_start
        previous = minute
    values = sorted(value for _, value, _ in combined)
    p95 = values[min(len(values) - 1, int(round(0.95 * (len(values) - 1))))]
    result.update(
        combined_average_MB_per_second=sum(values) / len(values),
        combined_p95_minute_MB_per_second=p95,
        combined_peak_minute_MB_per_second=peak, combined_peak_minute_utc=utc_text(peak_minute),
        combined_peak_percent_of_rate=peak / rate * 100,
        headroom_at_peak_MB_per_second=rate - peak,
        minutes_above_rate=len(above), percent_minutes_above_rate=len(above) / len(combined) * 100,
        longest_stretch_above_rate_minutes=longest,
        longest_stretch_above_rate_start_utc=utc_text(longest_start) if longest_start is not None else None,
        first_minutes_above_rate_utc=[utc_text(m) for m in above[:20]],
        contributors_at_peak=[{'server': name, 'MB_per_second': value}
                              for name, value in sorted(peak_parts.items(), key=lambda kv: kv[1], reverse=True)],
        busiest_minutes=[{'minute_utc': utc_text(m), 'MB_per_second': v}
                         for m, v, _ in sorted(combined, key=lambda row: row[1], reverse=True)[:10]])
    incomplete = result['servers_without_measurements'] or result['minutes_partial_coverage']
    if above:
        result.update(status='ABOVE_SHARED_RATE',
                      verdict='QUEUING EXPECTED: the combined fill rate exceeded %.3g MB/sec in %d of %d measured minutes.' % (rate, len(above), len(combined)))
    else:
        result.update(status='BELOW_SHARED_RATE',
                      verdict='No minute exceeded %.3g MB/sec; peak used %.0f%% of the shared rate (headroom %.3f MB/sec).'
                              % (rate, peak / rate * 100, rate - peak))
    if incomplete:
        result['coverage_warning'] = 'Some servers or minutes were not measured on every server; the combined result covers only fully measured minutes.'
    return result


# ---------------------------------------------------------------- per server

def rotation_proposal(server, cribl_rate=DEFAULT_CRIBL_RATE_MB_SEC):
    static = server.get('final_static_evidence') or {}
    objectives = static.get('assessment_objectives') or {}
    age = objectives.get('target_file_age_hours')
    cap = objectives.get('candidate_size_gb')
    recovery = objectives.get('recovery_hours')
    budget = objectives.get('disk_budget_gb')
    average = server.get('weighted_sample_average_MB_per_second')
    peak = server.get('peak_sample_MB_per_second')
    inv = static.get('final_inventory') or {}
    result = {
        'cribl_rate_MB_per_second_shared': cribl_rate,
        'server_average_percent_of_shared_rate': average / cribl_rate * 100 if average is not None else None,
        'server_peak_percent_of_shared_rate': peak / cribl_rate * 100 if peak is not None else None,
        'objectives': objectives, 'per_path': [],
        'filesystem_free_GB_at_setup': inv.get('filesystem_free_bytes', 0) / 1e9 if inv else None,
        'required_recovery_hours': recovery,
        'estimated_peak_growth_GB_for_recovery_window': peak * recovery * 3600 / 1000 if peak is not None and recovery else None,
        'operator_retention_budget_GB': budget,
        'candidate_size_GB_supplied': cap,
        'read_completion': 'UNKNOWN', 'safe_retention': 'UNKNOWN',
        'cleanup_script_review': 'MANUAL REVIEW REQUIRED',
        'limitations': ['The Cribl rate is customer-supplied and shared by all servers; this server alone gets only part of it.',
                        'Read time is file size / full shared rate, the best case; other servers compete for the same rate.',
                        'Raw cleanup scripts and policy declarations require manual interpretation, including dependencies and conflicting settings.',
                        'The recovery estimate is new uncompressed volume at the measured peak, not proof of safe retention.']}
    # Paths with no observed growth (rotated copies, idle sources) cannot be sized
    # and must not block a proposal for the paths that are actively written.
    result['idle_paths_excluded'] = []
    for row in server.get('per_path', []):
        r = row.get('peak_sample_MB_per_second') or 0
        if r <= 0:
            result['idle_paths_excluded'].append(row['path'])
            continue
        size_gb = r * age * 3600 / 1000 if age else None
        if size_gb is not None and cap is not None:
            size_gb = min(size_gb, cap)
        result['per_path'].append({
            'path': row['path'], 'sampled_peak_MB_per_second': r,
            'conditional_size_GB': size_gb, 'conditional_time_hours': age,
            'read_minutes_at_full_shared_rate': size_gb * 1000 / cribl_rate / 60 if size_gb is not None else None,
            'basis': 'Measured path peak multiplied by the supplied age objective, capped by the supplied size ceiling if any.' if size_gb is not None else 'Pending: supply a maximum file age objective.'})
    if result['idle_paths_excluded']:
        result['limitations'].append('Paths with no observed growth were excluded from sizing; confirm they are rotated copies or idle sources.')
    # Only blocking gaps prevent a proposal; advisory gaps lower confidence instead.
    blocking = server.get('blocking_gaps') or []
    advisory = [gap for gap in server.get('evidence_gaps') or [] if gap not in blocking]
    result['blocking_gaps'] = list(blocking)
    result['advisory_gaps'] = advisory
    result['confidence'] = 'REDUCED' if advisory else 'STANDARD'
    result['status'] = 'CONDITIONAL_PROPOSAL' if result['per_path'] and all(p['conditional_size_GB'] is not None for p in result['per_path']) and not blocking else 'INSUFFICIENT_EVIDENCE'
    if recovery and peak is not None and budget is not None:
        result['estimated_growth_vs_budget'] = 'EXCEEDS_BUDGET' if result['estimated_peak_growth_GB_for_recovery_window'] > budget else 'WITHIN_BUDGET_NOT_PROOF_OF_SAFETY'
    else:
        result['estimated_growth_vs_budget'] = 'UNKNOWN'
    required = result['estimated_peak_growth_GB_for_recovery_window']
    free = result['filesystem_free_GB_at_setup']
    result['estimated_new_growth_vs_free_space'] = ('UNKNOWN' if required is None or free is None else
        'EXCEEDS_SNAPSHOT_FREE_SPACE' if required > free else 'BELOW_SNAPSHOT_FREE_SPACE_NOT_PROOF_OF_SAFETY')
    return result


def mark_incomplete(item, gap):
    item.setdefault('evidence_gaps', []).append(gap)
    item.setdefault('blocking_gaps', []).append(gap)
    if item.get('rotation_proposal'):
        item['rotation_proposal']['status'] = 'INSUFFICIENT_EVIDENCE'
        item['rotation_proposal'].setdefault('blocking_gaps', []).append(gap)
    if item.get('evidence_assessment'):
        item['evidence_assessment']['status'] = 'INSUFFICIENT_EVIDENCE'


def summarize_server(item, cribl_rate):
    windows = sorted(item.pop('windows'), key=lambda w: w.get('started_utc', ''))
    total_seconds = sum(float(w.get('completed_observation_seconds') or 0) for w in windows)
    total_growth = sum(float(w['growth']['same_inode_growth_bytes']) for w in windows)
    rows = {}
    for window in windows:
        for row in window.get('per_active_path', []):
            value = rows.setdefault(row['path'], {'path': row['path'], 'observed_growth_bytes': 0, 'observed_seconds': 0, 'peak_sample_MB_per_second': 0})
            value['observed_growth_bytes'] += row.get('observed_growth_bytes', 0)
            value['observed_seconds'] += window.get('completed_observation_seconds', 0)
            value['peak_sample_MB_per_second'] = max(value['peak_sample_MB_per_second'], row.get('peak_sample_MB_per_second', 0))
    for row in rows.values():
        row['average_MB_per_second_when_observed'] = row['observed_growth_bytes'] / row['observed_seconds'] / 1e6 if row['observed_seconds'] else 0
    item.update(sample_count=len(windows), sampled_seconds=total_seconds,
                first_sample_started_utc=windows[0].get('started_utc') if windows else None,
                observed_growth_bytes=total_growth,
                weighted_sample_average_MB_per_second=total_growth / total_seconds / 1e6 if total_seconds else None,
                peak_sample_MB_per_second=max((w['growth']['peak_sample_MB_per_second'] for w in windows), default=None),
                scan_interval_seconds=max((w.get('configured_interval_seconds') or 0 for w in windows), default=None),
                per_path=list(rows.values()), minute_series=minute_series(windows),
                hourly_observations=[{'started_utc': w.get('started_utc'), 'elapsed_hours': hourly_intervals(w)} for w in windows if w.get('intervals')],
                maximum_scan_seconds=max((w.get('scan', {}).get('maximum_seconds', 0) for w in windows), default=None),
                sample_windows=[{'sample_label': w.get('sample_label'), 'started_utc': w.get('started_utc'),
                                 'observed_seconds': w.get('completed_observation_seconds'), 'growth': w.get('growth'),
                                 'scan': w.get('scan'), 'warnings': w.get('warnings')} for w in windows])
    gaps, blocking = [], []
    if not windows:
        gaps.append('No fill-rate measurements.'); blocking.append('No fill-rate measurements.')
    static = item['final_static_evidence']
    if not static:
        gaps.append('Setup snapshot is missing.'); blocking.append('Setup snapshot is missing.')
    elif static.get('scan', {}).get('error_count'):
        gaps.append('Setup inventory has scan errors; review reported paths.')
    if any(w.get('sample_label') == 'continuous_partial' for w in windows):
        gaps.append('Measurement was recovered from a checkpoint after an interruption.')
    if any(w.get('scan', {}).get('error_count') or any(w.get('growth', {}).get(k, 0) for k in ('newly_observed_file_count', 'truncation_count', 'disappeared_file_count')) for w in windows):
        gaps.append('Scan errors or file churn may understate growth; review individual windows.')
    change_counts = {key: sum(w.get('growth', {}).get(key, 0) or 0 for w in windows)
                     for key in ('newly_observed_file_count', 'truncation_count', 'disappeared_file_count', 'observed_path_change_count')}
    if change_counts['observed_path_change_count']:
        gaps.append('File path changes were observed; these may be renames or rotations and can obscure growth.')
    slow_scans = any(w.get('configured_interval_seconds') and w.get('scan', {}).get('maximum_seconds', 0) >= w['configured_interval_seconds'] for w in windows)
    if slow_scans:
        gaps.append('A scan took at least the configured interval; narrow the tree or increase the interval.')
    cleanup = (static or {}).get('cleanup_scripts', [])
    if not cleanup:
        gaps.append('No custom cleanup script selected; confirm whether one exists and review it.')
    elif any(script.get('status') != 'collected' for script in cleanup):
        gaps.append('A selected cleanup script could not be collected.')
    item['evidence_gaps'], item['blocking_gaps'] = gaps, blocking
    item['evidence_assessment'] = {
        'status': ('INSUFFICIENT_EVIDENCE' if blocking or not (item.get('peak_sample_MB_per_second') or 0) else
                   'LIMITED_BY_EVIDENCE_GAPS' if gaps else 'OBSERVED_WITH_LIMITATIONS'),
        'rotation_or_churn': 'POSSIBLE_CHANGES_OBSERVED' if any(change_counts.values()) else 'NO_CHANGES_OBSERVED',
        'observed_changes': change_counts, 'scan_at_or_above_interval': slow_scans,
        'interpretation': 'Observed changes may indicate rotation, renaming, truncation or deletion; lack of observed changes does not prove none occurred. Rates remain lower bounds.',
        'read_completion': 'UNKNOWN', 'safe_retention': 'UNKNOWN'}
    item['rotation_proposal'] = rotation_proposal(item, cribl_rate)
    return item


def build_summary(root, expected_servers=None, output_dir=None, cribl_rate=DEFAULT_CRIBL_RATE_MB_SEC):
    paths, errors = discover_reports(root, output_dir)
    groups, seen, saved_summaries = {}, {}, []
    if len(paths) > 10000:
        errors.append({'error': 'More than 10000 JSON files; additional inputs omitted.'})
    for path in paths[:10000]:
        try:
            data = read_report_json(path)
            if data.get('mode') == 'syslog_assessment_review':
                if data.get('sample_label') == 'final_assessment':
                    saved_summaries.append(data)
                continue
            if data.get('assessment_scope') != 'syslog_only' or data.get('mode') not in ('growth', 'baseline'):
                errors.append({'file': str(path), 'error': 'Not a report from this package version; skipped.'})
                continue
            host, directory = data.get('hostname'), data.get('directory')
            if not isinstance(host, str) or not host or not isinstance(directory, str) or not directory:
                raise ValueError('Missing hostname/directory')
            key = (host, directory)
            item = groups.setdefault(key, {'hostname': host, 'directory': directory, 'windows': [], 'final_static_evidence': None, 'source_reports': []})
            identity = (key, data['mode'], data.get('started_utc') or data.get('collected_utc'))
            if identity in seen:
                if seen[identity] != data:
                    raise ValueError('Conflicting copies of the same observation')
                continue
            seen[identity] = data
            item['source_reports'].append(str(path))
            if data['mode'] == 'baseline':
                old = item['final_static_evidence']
                if old is None or data.get('collected_utc', '') > old.get('collected_utc', ''):
                    item['final_static_evidence'] = data
            else:
                item['windows'].append(data)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            errors.append({'file': str(path), 'error': str(exc)})
    servers = [summarize_server(item, cribl_rate) for item in groups.values()]
    # Final reports copied from each server can be reviewed without raw files.
    # Raw measurements are preferred where both are present.
    by_key = {(s['hostname'], s['directory']): s for s in servers}
    summary_keys = {}
    for saved in saved_summaries:
        for item in saved.get('servers', []):
            key = (item['hostname'], item['directory'])
            run = item.get('assessment_run') or {}
            if key in by_key:
                raw_item = by_key[key]
                if run:
                    raw_item['assessment_run'] = run
                    if run.get('completed_as_planned') is False:
                        mark_incomplete(raw_item, 'Continuous observation did not complete as planned: ' + str(run.get('note')))
                continue
            if key in summary_keys and summary_keys[key] != item:
                errors.append({'error': 'Different final reports for one server/directory; keep one per server: ' + str(key)})
                continue
            summary_keys[key] = item
            if item.get('rotation_proposal'):
                # Re-evaluate with this review's shared rate.
                item['rotation_proposal'] = dict(item['rotation_proposal'], **{k: v for k, v in rotation_proposal(item, cribl_rate).items() if k not in ('status', 'blocking_gaps')})
    servers.extend(summary_keys.values())
    missing = sorted(set(expected_servers or ()) - {s['hostname'] for s in servers if s.get('sample_count')})
    common = {'status': 'INSUFFICIENT_EVIDENCE', 'reason': 'A fleet-wide setting requires representative data, objectives, reviewed cleanup behavior, disk/recovery requirements, and migration validation.'}
    proposals = [s.get('rotation_proposal', {}) for s in servers]
    if servers and not missing and not errors and all(p.get('status') == 'CONDITIONAL_PROPOSAL' for p in proposals):
        path_proposals = [p for server in proposals for p in server.get('per_path', [])]
        if path_proposals and all(p.get('conditional_size_GB') and p.get('conditional_time_hours') for p in path_proposals):
            common = {'status': 'CANDIDATE_FOR_MANUAL_REVIEW',
                      'candidate_size_GB': min(p['conditional_size_GB'] for p in path_proposals),
                      'candidate_time_hours': min(p['conditional_time_hours'] for p in path_proposals),
                      'reason': 'Smallest per-path size and time across included servers; a candidate, not a proven common policy.'}
    fleet = fleet_capacity(servers, cribl_rate)
    if missing:
        fleet['coverage_warning'] = 'Expected servers without measurements: ' + ', '.join(missing)
    return {'schema_version': '4.0', 'mode': 'syslog_assessment_review', 'reviewed_utc': datetime.now(timezone.utc).isoformat(),
            'cribl_rate_MB_per_second_shared': cribl_rate, 'fleet_vs_cribl': fleet,
            'servers': sorted(servers, key=lambda s: (s['hostname'], s['directory'])), 'errors': errors, 'missing_servers': missing,
            'common_policy': common,
            'limitations': ['Growth is a lower bound: new files, truncation and deletion can hide writes.',
                            'Rates use logical decimal MB/sec; per-interval peaks are not instantaneous maxima.',
                            'Setup settings describe their snapshot time, not necessarily the entire observation period.',
                            'No event content is read. No configuration changes are applied.']}


# ---------------------------------------------------------------- text output

def num(value, digits=3):
    """Readable fixed-precision number for text output; JSON keeps full values."""
    if value is None:
        return 'unknown'
    try:
        return '%.*f' % (digits, float(value))
    except (TypeError, ValueError):
        return str(value)


def hours_text(value):
    return num(value, 1).rstrip('0').rstrip('.') if value is not None else 'unknown'


def fleet_lines(fleet):
    rate = fleet.get('cribl_rate_MB_per_second_shared')
    lines = ['COMBINED FILL RATE vs CRIBL INGESTION (%s MB/sec shared by all servers)' % num(rate, 2),
             'Servers measured: %s' % fleet.get('servers_with_measurements', 0)]
    if fleet.get('minutes_combined') is not None:
        lines[-1] += '; minutes measured on every server: %s (partial: %s)' % (fleet['minutes_combined'], fleet.get('minutes_partial_coverage', 0))
    if fleet.get('combined_peak_minute_MB_per_second') is not None:
        lines += ['Combined peak minute: %s MB/sec at %s (%s%% of the shared rate)'
                  % (num(fleet['combined_peak_minute_MB_per_second']), fleet['combined_peak_minute_utc'], num(fleet['combined_peak_percent_of_rate'], 0)),
                  'Combined average: %s MB/sec; 95th percentile minute: %s MB/sec'
                  % (num(fleet['combined_average_MB_per_second']), num(fleet['combined_p95_minute_MB_per_second'])),
                  'Minutes above the shared rate: %s (%s%%); longest stretch: %s min%s'
                  % (fleet['minutes_above_rate'], num(fleet['percent_minutes_above_rate'], 1), fleet['longest_stretch_above_rate_minutes'],
                     ' from ' + fleet['longest_stretch_above_rate_start_utc'] if fleet.get('longest_stretch_above_rate_start_utc') else '')]
        top = fleet.get('contributors_at_peak', [])[:5]
        if len(top) > 1:
            lines.append('Largest contributors at the peak minute: ' + ', '.join('%s %s MB/sec' % (c['server'].split(' ')[0], num(c['MB_per_second'])) for c in top))
    lines.append('Result: ' + fleet.get('status', 'UNKNOWN') + ' - ' + fleet.get('verdict', ''))
    if fleet.get('coverage_warning'):
        lines.append('Coverage: ' + fleet['coverage_warning'])
    if fleet.get('servers_without_measurements'):
        lines.append('Servers without measurements: ' + ', '.join(fleet['servers_without_measurements']))
    return lines


def proposal_lines(proposal):
    """Status, gaps and per-path candidates, without the raw JSON details."""
    status = proposal.get('status', 'INSUFFICIENT_EVIDENCE')
    lines = ['Rotation candidate status: ' + status + ('' if status != 'CONDITIONAL_PROPOSAL' else
                                                       '   Confidence: ' + proposal.get('confidence', 'STANDARD'))]
    if status != 'CONDITIONAL_PROPOSAL':
        lines.append('Evidence is insufficient for an actionable recommendation; any figures below are preliminary.')
        for gap in proposal.get('blocking_gaps', []):
            lines.append('  Blocking gap: ' + gap)
    for gap in proposal.get('advisory_gaps', []):
        lines.append('  Advisory gap (reduces confidence): ' + gap)
    for path in proposal.get('per_path', []):
        size, hours = path.get('conditional_size_GB'), path.get('conditional_time_hours')
        lines.append('Path: ' + str(path.get('path')))
        if size is not None and hours is not None:
            lines.append('  Candidate: rotate at approximately %s GB OR after %s hours if the size is not reached.' % (num(size, 2), hours_text(hours)))
            lines.append('  Path peak %s MB/sec; reading one full file at the whole shared rate takes about %s minutes.'
                         % (num(path.get('sampled_peak_MB_per_second')), num(path.get('read_minutes_at_full_shared_rate'), 0)))
        else:
            lines.append('  Candidate pending: ' + str(path.get('basis', 'Insufficient evidence.')))
    if not proposal.get('per_path'):
        lines.append('  Candidate pending: no path showed positive growth during measurement.')
    if proposal.get('idle_paths_excluded'):
        lines.append('Idle paths excluded from sizing (no observed growth): ' + ', '.join(proposal['idle_paths_excluded']))
    return lines


def common_policy_line(common):
    if common.get('status') == 'CANDIDATE_FOR_MANUAL_REVIEW':
        return ('Common rotation candidate (MANUAL REVIEW ONLY): rotate at approximately %s GB OR after %s hours.'
                % (num(common.get('candidate_size_GB'), 2), hours_text(common.get('candidate_time_hours'))))
    return 'Common rotation candidate: %s - %s' % (common.get('status'), common.get('reason', ''))


def server_header(server, rate):
    lines = ['Server: %s   Directory: %s' % (server['hostname'], server['directory']),
             'Measured: %s hours%s; average %s MB/sec; peak interval %s MB/sec (%s%% of the shared rate)'
             % (num((server.get('sampled_seconds') or 0) / 3600, 1),
                ', scan every %s s' % num(server['scan_interval_seconds'], 0) if server.get('scan_interval_seconds') else '',
                num(server.get('weighted_sample_average_MB_per_second')), num(server.get('peak_sample_MB_per_second')),
                num((server.get('peak_sample_MB_per_second') or 0) / rate * 100, 0))]
    run = server.get('assessment_run') or {}
    if run:
        lines.append('Run: %s' % ('completed as planned' if run.get('completed_as_planned') else 'INCOMPLETE - ' + str(run.get('note'))))
    return lines


def render_brief(report):
    """Short terminal screen: fleet result first, then one block per server."""
    rate = report.get('cribl_rate_MB_per_second_shared', DEFAULT_CRIBL_RATE_MB_SEC)
    lines = ['SYSLOG FILE ASSESSMENT - SUMMARY', ''] + fleet_lines(report.get('fleet_vs_cribl') or {}) + ['']
    for server in report['servers']:
        lines += server_header(server, rate) + proposal_lines(server.get('rotation_proposal', {})) + ['']
    lines.append(common_policy_line(report['common_policy']))
    if report['missing_servers']:
        lines.append('Missing expected servers: ' + ', '.join(report['missing_servers']))
    if report['errors']:
        lines.append('Input errors: %d (see the full summary file)' % len(report['errors']))
    lines += ['', 'Read completion and safe retention remain UNKNOWN. Full evidence, configuration and cron details are in the summary file.']
    return '\n'.join(lines) + '\n'


def render_summary(report):
    rate = report.get('cribl_rate_MB_per_second_shared', DEFAULT_CRIBL_RATE_MB_SEC)
    fleet = report.get('fleet_vs_cribl') or {}
    lines = ['SYSLOG FILE ASSESSMENT', ''] + fleet_lines(fleet)
    if fleet.get('busiest_minutes'):
        lines.append('Busiest combined minutes: ' + '; '.join('%s %s MB/sec' % (m['minute_utc'], num(m['MB_per_second'])) for m in fleet['busiest_minutes']))
    lines += ['', common_policy_line(report['common_policy']), '']
    if report.get('assessment_run'):
        lines += ['Assessment run: ' + json.dumps(report['assessment_run']), '']
    for server in report['servers']:
        lines += server_header(server, rate) + proposal_lines(server.get('rotation_proposal', {}))
        lines += ['Read completion: UNKNOWN. Safe retention: UNKNOWN. Validate rotation-check cadence, overshoot and cleanup scripts during a pilot.',
                  'Per-path growth:']
        for row in server['per_path']:
            lines.append('  %s: average %s MB/sec; peak interval %s MB/sec'
                         % (row['path'], num(row['average_MB_per_second_when_observed']), num(row['peak_sample_MB_per_second'])))
        for block in server.get('hourly_observations') or []:
            lines.append('Hourly average MB/sec from %s: %s' % (block['started_utc'], ', '.join(num(h['average_MB_per_second']) for h in block['elapsed_hours'])))
        lines += ['Evidence gaps: ' + ('; '.join(server['evidence_gaps']) or 'none'), '', 'SUPPORTING EVIDENCE']
        if server.get('evidence_assessment'):
            lines.append('Evidence and rotation/churn: ' + json.dumps(server['evidence_assessment'], indent=2))
        static = server.get('final_static_evidence')
        if static:
            inv = static['final_inventory']
            lines += ['Setup snapshot collected UTC: ' + str(static.get('collected_utc')),
                      'Snapshot file count: %s; logical size %.3f GB; largest file %.3f GB; filesystem free %.3f GB'
                      % (inv['unique_regular_files'], inv['logical_bytes'] / 1e9, inv['largest_file_bytes'] / 1e9, inv['filesystem_free_bytes'] / 1e9),
                      'Installed versions/resources:\n' + json.dumps(static['system_info'], indent=2),
                      'Existing rotation/retention declarations:\n' + json.dumps(static['policies'], indent=2),
                      'Existing rotation cron/timer evidence:\n' + json.dumps(static['cron_policies'], indent=2),
                      'Custom cleanup scripts (UNREDACTED; manual review):\n' + json.dumps(static.get('cleanup_scripts', []), indent=2)]
        lines += ['Rotation candidate details: ' + json.dumps(server.get('rotation_proposal', {}), indent=2), '']
    lines += ['TUNING REVIEW',
              'Approximate file size MB = MB/sec x seconds between rotations; allow for writes between rotation checks.',
              'Choose server-specific settings first; compare any common candidate against every included server.',
              'Common rotation evaluation: ' + json.dumps(report['common_policy']), '']
    if report['missing_servers']:
        lines.append('Missing expected servers: ' + ', '.join(report['missing_servers']))
    if report['errors']:
        lines.append('Input errors: ' + json.dumps(report['errors']))
    lines += ['LIMITATIONS'] + report['limitations'] + fleet.get('limitations', [])
    return '\n'.join(lines) + '\n'
