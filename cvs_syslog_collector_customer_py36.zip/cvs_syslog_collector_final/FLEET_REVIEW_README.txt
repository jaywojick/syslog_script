CENTRAL FLEET REVIEW — LOCAL REPORTS ONLY

1. Run the continuous assessment on every server over the same period
   (python3 syslog_menu.py, same start time on each server).
2. Copy each server's syslog_<host>_<time>_final_assessment.json into one
   folder on a review machine (subfolders are fine).
3. Optional: list every expected server, one exact hostname per line
   (see expected_servers_template.txt), to flag missing servers.
4. From this package on the review machine:
     python3 syslog_fleet_review.py
   Prompts: report folder, output folder, optional server list,
   Cribl ingestion rate shared by all servers [2.4 MB/sec].
   One-line form:
     python3 syslog_fleet_review.py /customer-reports --output-dir /fleet-results \
         --expected-servers-file /expected-servers.txt --cribl-rate 2.4

Output
  A short screen summary plus private JSON and full text reports:
    Combined peak minute, average and 95th percentile (MB/sec) vs the shared rate
    Minutes above the shared rate and the longest stretch above it
    Result: BELOW_SHARED_RATE or ABOVE_SHARED_RATE (queuing expected)
    Largest contributors at the peak minute
    Per-server rotation candidates and a common candidate for MANUAL REVIEW
  Only minutes measured on every server are combined. If the runs did not
  overlap, the result is NO_COMMON_COVERAGE; re-run with the same start time.

No network calls, remote changes or source-file changes occur.
