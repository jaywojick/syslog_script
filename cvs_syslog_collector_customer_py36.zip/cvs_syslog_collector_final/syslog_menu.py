#!/usr/bin/env python3
"""Guided setup for the syslog file assessment. Python 3.6+, standard library only."""
import argparse
import os
from pathlib import Path
import subprocess
import sys


def ui_input(prompt):
    # Color the prompt and echoed answer separately; terminals may opt out.
    if sys.stdout.isatty() and not os.environ.get('NO_COLOR') and os.environ.get('TERM') != 'dumb':
        try:
            return input('\033[1;36m' + prompt + '\033[0m\033[1;33m')
        finally:
            sys.stdout.write('\033[0m')
            sys.stdout.flush()
    return input(prompt)


def prompt_path(label, default=None, directory=False, must_exist=False):
    while True:
        suffix = ' [%s]' % default if default is not None else ''
        value = ui_input(label + suffix + ': ').strip() or default
        if not value:
            print('Enter a path.')
            continue
        path = Path(value).expanduser().absolute()
        if must_exist and not (path.is_dir() if directory else path.is_file()):
            print('Path must be an existing %s.' % ('directory' if directory else 'file'))
            continue
        return path


def prompt_seconds(label, default, unit=None):
    # Reuse collector validation, including rejection of NaN and infinity.
    from syslog_sizing import positive
    while True:
        value = ui_input('%s [%s%s]: ' % (label, default, ' ' + unit if unit else '')).strip() or default
        try:
            positive(value)
            return value
        except argparse.ArgumentTypeError as exc:
            print(str(exc))


def optional_positive(label):
    from syslog_sizing import positive
    while True:
        value = ui_input(label + ' (Enter if unknown): ').strip()
        if not value:
            return None
        try:
            positive(value)
            return value
        except argparse.ArgumentTypeError as exc:
            print(str(exc))


def optional_files(label):
    paths = []
    while True:
        value = ui_input(label + ' (Enter to finish): ').strip()
        if not value:
            return paths
        path = Path(value).expanduser().absolute()
        if not path.is_file():
            print('Enter an existing file path.')
            continue
        paths.append(path)


def main():
    if not sys.stdin.isatty():
        print('Run this guided setup in a terminal.', file=sys.stderr)
        return 2
    from syslog_runner import configure_syslog_assessment
    print('\nSYSLOG FILE ASSESSMENT - fill rates and existing configuration')
    print('Reads file metadata and rotation configuration only. No syslog configuration changes.')
    try:
        configure_syslog_assessment()
        return 0
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        print('Assessment setup failed: ' + str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (EOFError, KeyboardInterrupt):
        print('\nAssessment closed.', file=sys.stderr)
        sys.exit(130)
