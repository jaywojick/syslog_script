#!/usr/bin/env python3
"""Syslog file inventory, sampled fill rates and existing rotation evidence.

Python 3.6+, standard library only. Keep the package files together.
Reads file metadata, never log contents. The setup snapshot (--baseline) also
reads selected rotation/cron configuration files; --include-policy-configs
embeds their text UNREDACTED, so review reports before sharing.
No source files or configuration are changed and collected commands are never
executed. Output is private timestamped JSON when --report-dir is supplied,
otherwise JSON on stdout. MB/GB are decimal. Run on a narrowly scoped directory.

Normally started by syslog_menu.py and the assessment schedule.
"""
import argparse
import fnmatch
import json
import math
import glob
import re
import shlex
import os
from pathlib import Path
import shutil
import socket
import stat
import sys
import time
from datetime import datetime, timezone

ARCHIVES = ('.gz', '.bz2', '.xz', '.zst', '.zip', '.tar', '.tgz', '.lz4', '.7z')
DAY = 86400.0


def collect_cleanup_scripts(paths):
    result, total = [], 0
    for name in paths:
        row = {'path': str(name)}
        try:
            fd = os.open(str(name), os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
            with os.fdopen(fd, 'rb') as stream:
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_size > 2 * 1024 * 1024:
                    raise ValueError('Not a regular file or larger than 2 MiB')
                data = stream.read(2 * 1024 * 1024 + 1)
            total += len(data)
            if len(data) > 2 * 1024 * 1024 or total > 8 * 1024 * 1024:
                raise ValueError('Script collection limit exceeded')
            if b'\x00' in data:
                raise ValueError('Binary script rejected')
            row.update(status='collected', text=data.decode('utf-8'))
        except (OSError, ValueError, UnicodeError) as exc:
            row.update(status='error', error=str(exc))
        result.append(row)
    return result


def positive(value):
    try:
        value = float(value)
    except (ValueError, TypeError):
        raise argparse.ArgumentTypeError('must be a positive finite number')
    if not math.isfinite(value) or value <= 0:
        raise argparse.ArgumentTypeError('must be a finite number greater than zero')
    return value


def nonnegative(value):
    value = int(value)
    if value < 0:
        raise argparse.ArgumentTypeError('must be zero or greater')
    return value


def active(name, patterns):
    return not name.lower().endswith(ARCHIVES) and any(
        fnmatch.fnmatchcase(name, p) or fnmatch.fnmatchcase(Path(name).name, p)
        for p in patterns
    )


def scan(root, max_depth):
    """Return one entry per device/inode; no symlinks followed."""
    files, errors, seen = {}, [], set()
    start = time.monotonic()
    stack = [(root, 0)]
    links = 0
    while stack:
        directory, depth = stack.pop()
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    try:
                        info = entry.stat(follow_symlinks=False)
                        if stat.S_ISDIR(info.st_mode):
                            if max_depth is None or depth < max_depth:
                                stack.append((Path(entry.path), depth + 1))
                        elif stat.S_ISREG(info.st_mode):
                            name = str(Path(entry.path).relative_to(root))
                            key = (info.st_dev, info.st_ino)
                            links += 1
                            # Keep aliases to handle hard-linked active/rotated names.
                            if key not in seen:
                                files[key] = {'paths': [name], 'size': info.st_size,
                                              'mtime': info.st_mtime}
                                seen.add(key)
                            else:
                                files[key]['paths'].append(name)
                    except OSError as exc:
                        errors.append(str(exc))
        except OSError as exc:
            errors.append(str(exc))
    return files, errors, time.monotonic() - start, links


def choose_active(row, patterns):
    matches = sorted(p for p in row['paths'] if active(p, patterns))
    return matches[0] if matches else None


def inventory(files, links, root, top, include_files=False):
    sizes = sorted(row['size'] for row in files.values())
    now = time.time()
    bands = {'under_1_day': 0, '1_to_7_days': 0, '7_to_30_days': 0,
             '30_days_or_older': 0, 'future_mtime': 0}
    for row in files.values():
        age = now - row['mtime']
        label = ('future_mtime' if age < 0 else 'under_1_day' if age < DAY else
                 '1_to_7_days' if age < 7 * DAY else
                 '7_to_30_days' if age < 30 * DAY else '30_days_or_older')
        bands[label] += 1
    disk = shutil.disk_usage(root)
    result = {'directory_entries': links, 'unique_regular_files': len(files),
              'filesystem_device_count': len({key[0] for key in files}),
            'logical_bytes': sum(sizes),
            'average_file_bytes': sum(sizes) / len(sizes) if sizes else 0,
            'largest_file_bytes': sizes[-1] if sizes else 0,
            'files_by_modification_age': bands,
            'filesystem_total_bytes': disk.total, 'filesystem_free_bytes': disk.free,
            'largest_files': [{'path': sorted(r['paths'])[0], 'bytes': r['size']}
                              for r in sorted(files.values(),
                                              key=lambda r: r['size'], reverse=True)[:top]]}
    if include_files:
        result['all_files'] = sorted(
            [{'path': name, 'bytes': row['size'], 'mtime_epoch': row['mtime'],
              'hardlink_alias_count': len(row['paths'])}
             for row in files.values() for name in row['paths']],
            key=lambda row: (-row['bytes'], row['path']))
    return result


def find_path_changes(previous, current):
    """Detect changed path sets on the same inode; this is not proof of rotation."""
    return [{'from': sorted(previous[key]['paths']), 'to': sorted(current[key]['paths'])}
            for key in previous.keys() & current.keys()
            if set(previous[key]['paths']) != set(current[key]['paths'])]


def compare(previous, current, patterns):
    growth = {}
    new_bytes = new_count = truncated_bytes = truncated_count = disappeared = 0
    for key, row in current.items():
        old = previous.get(key)
        name = (choose_active(old, patterns) if old else None) or choose_active(row, patterns)
        if not name:
            continue
        if old is None:
            new_count += 1
            new_bytes += row['size']
        elif row['size'] >= old['size']:
            growth[name] = growth.get(name, 0) + row['size'] - old['size']
        else:
            truncated_count += 1
            truncated_bytes += row['size']
    for key, row in previous.items():
        if key not in current and choose_active(row, patterns):
            disappeared += 1
    return growth, new_count, new_bytes, truncated_count, truncated_bytes, disappeared



# This collector deliberately reports declarations, not a purported effective
# policy. Logrotate directive order, includes, scheduler and local versions matter.
LR_DIRECTIVES = set('hourly daily weekly monthly yearly minutes size minsize maxsize rotate maxage minage compress nocompress delaycompress nodelaycompress copytruncate nocopytruncate copy nocopy renamecopy norenamecopy create nocreate createolddir nocreateolddir olddir noolddir dateext nodateext dateformat dateyesterday datehourago ifempty notifempty missingok nomissingok sharedscripts nosharedscripts start su extension addextension shred noshred shredcycles tabooext taboopat'.split())
LR_SCRIPTS = {'prerotate', 'postrotate', 'firstaction', 'lastaction', 'preremove'}
MAX_CONFIG_BYTES = 2 * 1024 * 1024
MAX_CONFIG_TEXT_BYTES = 8 * 1024 * 1024


def read_regular_text(path, max_bytes=MAX_CONFIG_BYTES):
    """Read bounded config bytes; never execute content or read special devices."""
    flags = os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0) | getattr(os, 'O_NOCTTY', 0)
    fd = os.open(str(path), flags)
    with os.fdopen(fd, 'rb') as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError('not a regular file')
        raw = stream.read(max_bytes + 1)
    if len(raw) > max_bytes:
        raise ValueError('file exceeds %d-byte safety limit' % max_bytes)
    if b'\x00' in raw:
        raise ValueError('binary content refused')
    return raw.decode('utf-8', errors='replace')


def collect_policies(logrotate_config, rsyslog_config, syslog_ng_config, include_config_text=False):
    report = {
        'collection_type': 'best-effort declarations; NOT validated effective policies',
        'logrotate': {'global_directives_in_encounter_order': [], 'stanzas': [], 'includes': [], 'unparsed_locations': []},
        'syslog_rotation_settings': [], 'syslog_includes_not_expanded': [],
        'scheduler_declarations': [], 'scheduler_file_presence': [],
        'files_read': [], 'missing_roots': [], 'errors': [],
        'warnings': [
            'Logrotate globals and stanza settings are separate and ordered. Inheritance/precedence is NOT resolved; missing values mean unspecified here, not disabled.',
            'size, minsize and maxsize have different semantics. Do not assume an existing size plus time policy means OR. The collector does not evaluate trigger precedence.',
            'rotate is a retained-file count, not a time/size trigger. Actual retention depends on rotation frequency, maxage and other directives.',
            'Settings are not automatically fed into the sizing model. Supply modeling assumptions explicitly.',
            'Custom rotation scripts/commands are flagged, never executed or printed. They require separate review.',
            'Only conventional Linux config locations plus explicitly selected roots are checked. Application policies, remote config, custom schedulers, syslog includes and conditional config may be missing.',
            'Systemd timer declarations are not proof a timer is enabled or running. Cron file presence is not proof of execution.',
            'Review directory names and paths before sharing the report. Log contents and complete configuration files are not emitted.'
        ]}
    report['configuration_text_included'] = bool(include_config_text)
    if include_config_text:
        report['configuration_files'] = {}
        report['warnings'].append('RAW CONFIG TEXT ENABLED: configuration text and embedded script bodies may contain passwords, tokens, certificates, endpoints or internal details. No automatic redaction. Review and redact before sharing. No commands are executed.')
        report['warnings'].append('Embedded text is limited to 2 MiB per file and 8 MiB total. Skipped/unreadable files and unresolved includes mean this is NOT a complete effective configuration.')
        report['warnings'] = [w for w in report['warnings'] if w not in (
            'Custom rotation scripts/commands are flagged, never executed or printed. They require separate review.',
            'Review directory names and paths before sharing the report. Log contents and complete configuration files are not emitted.')]
    reads = set()
    config_text_bytes = 0

    def read(path, root=False):
        nonlocal config_text_bytes
        path = Path(path)
        if not path.exists():
            if root:
                report['missing_roots'].append(str(path))
            else:
                report['errors'].append({'file': str(path), 'error': 'referenced configuration missing'})
            return None
        if len(reads) >= 200 and str(path) not in reads:
            report['errors'].append({'file': str(path), 'error': '200-config safety limit reached'})
            return None
        try:
            text = read_regular_text(path)
            reads.add(str(path))
            if include_config_text and str(path) not in report['configuration_files']:
                text_bytes = len(text.encode('utf-8'))
                if config_text_bytes + text_bytes > MAX_CONFIG_TEXT_BYTES:
                    report['configuration_files'][str(path)] = {'content_omitted': True, 'reason': '8 MiB total configuration-text limit reached'}
                    report['warnings'].append('Configuration text omitted for %s: total output limit reached.' % path)
                else:
                    report['configuration_files'][str(path)] = {
                        'text': text, 'line_count': len(text.splitlines()),
                        'redacted': False, 'review_before_sharing': True}
                    config_text_bytes += text_bytes
            return text
        except (OSError, ValueError) as exc:
            report['errors'].append({'file': str(path), 'error': str(exc)})
            return None

    def clean(line):
        # Only remove comments outside quotes; preserve escaped characters.
        quote, escaped, result = None, False, []
        for char in line:
            if escaped:
                result.append(char); escaped = False; continue
            if char == '\\':
                result.append(char); escaped = True; continue
            if quote:
                if char == quote: quote = None
            elif char in ('"', "'"):
                quote = char
            elif char == '#':
                break
            result.append(char)
        return ''.join(result).strip()

    visited = set()
    def parse_logrotate(path, depth=0, root=False):
        path = Path(path)
        if depth > 20:
            report['errors'].append({'file': str(path), 'error': 'include depth limit reached'})
            return
        if path.is_dir():
            # Common package backup files are skipped; taboo overrides not evaluated.
            report['warnings'].append('Include directory %s: common package/backup filenames skipped; custom taboo rules not evaluated.' % path)
            try:
                children = sorted(path.iterdir())
            except OSError as exc:
                report['errors'].append({'file': str(path), 'error': str(exc)}); return
            for child in children:
                if child.is_file() and not child.name.startswith('.') and not child.name.endswith(('~', '.bak', '.swp', '.rpmnew', '.rpmsave', '.rpmorig', '.dpkg-old', '.dpkg-dist', '.dpkg-new', '.disabled')):
                    parse_logrotate(child, depth + 1)
            return
        resolved = str(path.resolve())
        if resolved in visited:
            report['errors'].append({'file': str(path), 'error': 'duplicate/cyclic include skipped'})
            return
        visited.add(resolved)
        text = read(path, root)
        if text is None: return
        block, pending, script = None, [], False
        for number, raw in enumerate(text.splitlines(), 1):
            line = clean(raw)
            location = {'file': str(path), 'line': number}
            if script:
                if line == 'endscript': script = False
                continue
            if not line: continue
            if line in LR_SCRIPTS:
                if block is not None:
                    block['script_hooks_present'].append(dict(location, hook=line))
                else:
                    report['logrotate']['unparsed_locations'].append(dict(location, reason='script hook outside stanza'))
                script = True
                continue
            if line == '}':
                if block is not None:
                    report['logrotate']['stanzas'].append(block)
                else:
                    report['logrotate']['unparsed_locations'].append(dict(location, reason='unexpected closing brace'))
                block, pending = None, []
                continue
            if '{' in line:
                if block is not None or not line.endswith('{'):
                    report['logrotate']['unparsed_locations'].append(dict(location, reason='inline/nested syntax requires review; stanza not interpreted'))
                    pending = []
                    continue
                target_text = ' '.join(pending + [line[:-1].strip()])
                try:
                    targets = shlex.split(target_text)
                except ValueError:
                    targets = []
                block = dict(location, targets=targets, local_directives_in_order=[], script_hooks_present=[])
                pending = []
                continue
            tokens = line.split(None, 1)
            key = tokens[0]
            value = tokens[1] if len(tokens) > 1 else None
            if key == 'include' and block is None:
                try:
                    refs = shlex.split(value or '')
                except ValueError:
                    refs = []
                if len(refs) != 1 or not os.path.isabs(refs[0]):
                    report['logrotate']['unparsed_locations'].append(dict(location, reason='non-absolute/dynamic include requires review'))
                    continue
                ref = refs[0]
                report['logrotate']['includes'].append(dict(location, path=ref))
                matches = sorted(glob.glob(ref))
                if not matches:
                    report['errors'].append(dict(location, error='include path has no matches', path=ref))
                for match in matches:
                    parse_logrotate(match, depth + 1)
            elif key in LR_DIRECTIVES:
                setting = dict(location, directive=key, value=value)
                if block is None:
                    report['logrotate']['global_directives_in_encounter_order'].append(setting)
                else:
                    block['local_directives_in_order'].append(setting)
            elif block is None and line.startswith(('/', '"', "'")):
                pending.append(line)
            else:
                report['logrotate']['unparsed_locations'].append(dict(location, reason='unrecognized directive or syntax; contents omitted'))
        if block is not None or pending or script:
            report['logrotate']['unparsed_locations'].append({'file':str(path), 'reason':'incomplete stanza/header/script at end of file'})

    parse_logrotate(logrotate_config, root=True)
    # Select conventional syslog configs, without emitting full configs, shell
    # commands, credentials, arbitrary destination parameters or log contents.
    for product, root, confdir in [('rsyslog', rsyslog_config, '/etc/rsyslog.d'),
                                   ('syslog-ng', syslog_ng_config, '/etc/syslog-ng/conf.d')]:
        paths = [Path(root)]
        default = '/etc/rsyslog.conf' if product == 'rsyslog' else '/etc/syslog-ng/syslog-ng.conf'
        if str(root) == default:
            paths.extend(sorted(Path(confdir).glob('*.conf')))
        for path in paths:
            text = read(path, root=(str(path) == str(root)))
            if text is None: continue
            for number, raw in enumerate(text.splitlines(), 1):
                line = clean(raw)
                if not line: continue
                loc = {'product': product, 'file':str(path), 'line':number}
                if re.search(r'(?i)(\$IncludeConfig\b|\binclude\s*\(|@include\b)', line):
                    report['syslog_includes_not_expanded'].append(dict(loc, note='include present; expand manually if outside conventional conf.d paths'))
                for match in re.finditer(r'(?i)(rotation\.sizeLimit|\$OMFileSizeLimit)\s*(?:=\s*)?["\x27]?([0-9]+[kmg]?)', line):
                    report['syslog_rotation_settings'].append(dict(loc, setting=match.group(1), configured_value=match.group(2)))
                if re.search(r'(?i)(rotation\.sizeLimitCommand|\$OMFileSizeLimitCommand)\b', line):
                    report['syslog_rotation_settings'].append(dict(loc, setting='size-limit rotation command present', note='command omitted; review manually'))
                if re.search(r'(?i)^\s*\$outchannel\b', line):
                    report['syslog_rotation_settings'].append(dict(loc, setting='legacy outchannel present', note='may define size limit and custom rotation command; review manually'))
                if product == 'syslog-ng' and re.search(r'(?i)(logrotate|rotate|rotation|log-rotate)', line):
                    report['syslog_rotation_settings'].append(dict(loc, setting='rotation-related declaration present', note='custom syntax requires manual review; contents omitted'))
    timer_paths = [Path(x) for x in ['/etc/systemd/system/logrotate.timer', '/usr/lib/systemd/system/logrotate.timer', '/lib/systemd/system/logrotate.timer']]
    for directory in ['/etc/systemd/system/logrotate.timer.d', '/usr/lib/systemd/system/logrotate.timer.d', '/lib/systemd/system/logrotate.timer.d']:
        timer_paths.extend(sorted(Path(directory).glob('*.conf')))
    timer_seen = set()
    for path in timer_paths:
        if not path.exists() or str(path.resolve()) in timer_seen: continue
        timer_seen.add(str(path.resolve()))
        text = read(path)
        if text is None: continue
        for number, raw in enumerate(text.splitlines(), 1):
            line = clean(raw)
            match = re.match(r'(OnCalendar|OnBootSec|OnUnitActiveSec|OnUnitInactiveSec|AccuracySec|RandomizedDelaySec|Persistent)\s*=\s*(.*)$', line)
            if match:
                report['scheduler_declarations'].append({'file':str(path), 'line':number, 'setting':match.group(1), 'value':match.group(2)})
    for path in ['/etc/cron.daily/logrotate', '/etc/cron.hourly/logrotate', '/etc/cron.weekly/logrotate', '/etc/cron.d/logrotate']:
        if Path(path).exists():
            report['scheduler_file_presence'].append({'path':path, 'note':'present; execution/enabled state not checked'})
            if include_config_text:
                read(path)
    report['files_read'] = sorted(reads)
    return report



def schedule_description(schedule, kind):
    if kind == 'anacrontab':
        parts = schedule.split()
        if len(parts) >= 2:
            return 'Anacron period %s day(s), delay %s minute(s); execution also depends on startup/hour-range/random-delay settings.' % (parts[0], parts[1])
    names = {'@hourly': 'Hourly', '@daily': 'Daily', '@midnight': 'Daily',
             '@weekly': 'Weekly', '@monthly': 'Monthly', '@yearly': 'Yearly', '@reboot': 'At cron startup'}
    if schedule in names:
        return names[schedule] + '; subject to the existing scheduler/timezone.'
    parts = schedule.split()
    if len(parts) == 5:
        minute, hour, day, month, weekday = parts
        if minute.isdigit() and hour.isdigit() and day == month == weekday == '*':
            if int(minute) < 60 and int(hour) < 24:
                return 'Daily at %02d:%02d in the cron job timezone.' % (int(hour), int(minute))
        if minute.isdigit() and hour == day == month == weekday == '*' and int(minute) < 60:
            return 'Hourly at minute %02d in the cron job timezone.' % int(minute)
        if re.fullmatch(r'\*/[1-9]\d*', minute) and hour == day == month == weekday == '*':
            return 'Every %s minutes within each hour, per the cron expression.' % minute[2:]
    return 'Cron expression as written: ' + schedule + '; confirm timezone and scheduler behavior.'


def collect_cron_policies(include_config_text=False, cron_files=None,
                          system_root=Path('/')):
    """Inventory scheduler configuration and periodic job names; never run jobs.

    Referenced scripts and periodic job bodies are not collected. Use --cron-file
    only for a relevant exported crontab. No custom script input is supported.
    """
    root = Path(system_root)
    report = {
        'collection_type': 'Read-only scheduler evidence; NOT effective policy validation',
        'configuration_text_included': bool(include_config_text),
        'files': [], 'cron_entries': [], 'schedule_review_hints': [], 'errors': [],
        'missing_explicit_paths': [], 'timezone_declarations': [],
        'warnings': [
            'Scheduler files and schedules are evidence only; enabled/running status is NOT verified.',
            'All non-comment entries in selected crontabs are listed by schedule and source line. Commands appear only with --include-policy-configs.',
            'Referenced scripts and periodic job bodies are not collected or executed.',
            'Other users crontabs and custom systemd timers are not automatically collected. Relevant exported crontabs can be selected with --cron-file.',
            'Schedule review hints are lexical matches, not an interpretation of runtime behavior.',
            'No files are changed and no collected command or script is executed.'
        ]}
    if include_config_text:
        report['warnings'].append('UNREDACTED TEXT: cron commands may contain secrets. Review/redact before sharing. Text capped at 2 MiB per file and 8 MiB for this section.')
    paths = [(root/'etc/crontab', 'system_crontab', False),
             (root/'etc/anacrontab', 'anacrontab', False)]
    for directory in ['etc/cron.d', 'etc/cron.hourly', 'etc/cron.daily', 'etc/cron.weekly', 'etc/cron.monthly']:
        base = root/directory
        if not base.exists():
            continue
        try:
            for path in sorted(base.iterdir()):
                if not path.name.startswith('.') and not path.name.endswith(('~', '.bak', '.disabled', '.rpmnew', '.rpmsave', '.dpkg-old', '.dpkg-dist')):
                    paths.append((path, 'system_crontab' if directory == 'etc/cron.d' else 'periodic_job', False))
        except OSError as exc:
            report['errors'].append({'file': str(base), 'error': str(exc)})
    paths += [(Path(path), 'explicit_cron_file', True) for path in (cron_files or [])]
    seen, output_bytes = set(), 0
    for path, kind, explicit in paths:
        if len(seen) >= 200:
            report['warnings'].append('200 scheduler-file safety limit reached; remaining files skipped.')
            break
        try:
            identity = str(path.resolve())
            if identity in seen:
                continue
            seen.add(identity)
            if not path.exists():
                if explicit:
                    report['missing_explicit_paths'].append(str(path))
                continue
            if kind == 'periodic_job':
                rotation_related = bool(re.search(r'logrotate|rotat', path.name, re.I))
                report['files'].append({'path': str(path), 'kind': kind,
                                        'rotation_candidate_by_name': rotation_related,
                                        'periodic_directory': str(path.parent),
                                        'contents_collected': False, 'commands_executed': False})
                continue
            text = read_regular_text(path)
        except (OSError, ValueError, RuntimeError) as exc:
            report['errors'].append({'file': str(path), 'error': str(exc)})
            continue
        item = {'path': str(path), 'kind': kind, 'line_count': len(text.splitlines()),
                'commands_executed': False}
        if include_config_text:
            size = len(text.encode('utf-8'))
            if output_bytes + size <= MAX_CONFIG_TEXT_BYTES:
                item.update(text=text, redacted=False, review_before_sharing=True)
                output_bytes += size
            else:
                item['text_omitted'] = '8 MiB section limit reached'
                report['warnings'].append('Configuration text omitted for %s: section limit reached.' % path)
        report['files'].append(item)
        for line_number, raw in enumerate(text.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            if kind in ('system_crontab', 'explicit_cron_file', 'anacrontab'):
                if re.match(r'^[A-Za-z_][A-Za-z_0-9]*\s*=', line):
                    key, _, value = line.partition('=')
                    if key.strip() in ('CRON_TZ', 'TZ', 'START_HOURS_RANGE', 'RANDOM_DELAY'):
                        report['timezone_declarations'].append({'file': str(path), 'line': line_number,
                                                               'setting': key.strip(), 'value_as_written': value.strip()})
                    continue  # other environment assignments require raw-text opt-in
                fields = line.split()
                if kind == 'anacrontab':
                    schedule = ' '.join(fields[:3])
                elif line.startswith('@'):
                    schedule = fields[0]
                else:
                    schedule = ' '.join(fields[:5])
                entry = {'file': str(path), 'line': line_number,
                         'schedule_as_written': schedule,
                         'syntax_validated': False, 'command_omitted': not include_config_text}
                if include_config_text and 'text' in item:
                    entry['entry_text'] = raw
                elif include_config_text:
                    entry['command_omitted'] = True
                entry['schedule_description'] = schedule_description(schedule, kind)
                assessment = any(name in line for name in ('syslog_runner.py', 'syslog_sizing.py', 'syslog_menu.py'))
                entry['assessment_collector_job'] = assessment
                entry['rotation_candidate_by_command'] = not assessment and bool(re.search(r'logrotate|rotat', line, re.I))
                periodic = re.search(r'(?:/etc/)?cron\.(hourly|daily|weekly|monthly)\b', line)
                if periodic:
                    entry['periodic_directory'] = '/etc/cron.' + periodic[1]
                report['cron_entries'].append(entry)
            hints = []
            for name, pattern in [
                ('age_based_cleanup_candidate', r'(?<!\w)-(?:mtime|mmin|ctime|cmin)\b'),
                ('deletion_candidate', r'(?<![\w-])(?:rm|unlink)\s|(?<!\w)-delete\b'),
                ('truncation_candidate', r'\b(?:truncate|copytruncate)\b'),
                ('compression_candidate', r'\b(?:gzip|bzip2|xz|zstd|compress)\b'),
                ('disk_usage_check_candidate', r'(?<!\w)df\s'),
                ('rotation_reference_candidate', r'(?i)logrotate|syslog|rotat|retention|cleanup|purge')]:
                if re.search(pattern, line):
                    hints.append(name)
            if hints:
                report['schedule_review_hints'].append({'file': str(path), 'line': line_number,
                                                      'hints': hints, 'requires_manual_review': True})
    return report


def emit_json_report(report, report_dir=None, monitored_root=None):
    """Write stdout or a new private report; refuse outputs under scanned logs."""
    if report_dir is None:
        print(json.dumps(report, indent=2))
        return
    directory = Path(report_dir).expanduser().absolute()
    resolved = directory.resolve()
    if monitored_root is not None and os.path.commonpath([str(resolved), str(monitored_root)]) == str(monitored_root):
        raise ValueError('report directory must be outside the monitored log directory')
    directory.mkdir(parents=True, mode=0o700, exist_ok=True)
    mode = directory.lstat().st_mode
    if stat.S_ISLNK(mode) or not stat.S_ISDIR(mode) or mode & 0o077:
        raise ValueError('report directory must be a real directory with mode 0700 (no group/other permissions)')
    host = re.sub(r'[^A-Za-z0-9_.-]', '_', socket.gethostname())[:100] or 'host'
    label = re.sub(r'[^A-Za-z0-9_-]', '_', str(report.get('sample_label') or ''))[:32]
    suffix = '_' + label if label else ''
    name = 'syslog_%s_%s%s.json' % (host, datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ'), suffix)
    output = directory/name
    fd = os.open(str(output), os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')
    except BaseException:
        output.unlink()
        raise
    print('Report: %s' % output, file=sys.stderr)
    summary = None
    if report.get('mode') == 'syslog_assessment_review':
        from syslog_assessment_report import render_summary
        summary, label = render_summary(report), 'Assessment summary'
    elif report.get('mode') == 'baseline':
        summary = ('SYSLOG STATIC SNAPSHOT\nCollected UTC: ' + str(report.get('collected_utc')) +
                   '\nSnapshot role: ' + str(report.get('sample_label')) + '\n\n' + json.dumps(report, indent=2) + '\n')
        label = 'Static snapshot'
    if summary:
        summary_path = output.with_suffix('.txt')
        fd = os.open(str(summary_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(summary)
        print('%s: %s' % (label, summary_path), file=sys.stderr)
    return output


CHECKPOINT_NAME = 'continuous.checkpoint'


def write_checkpoint(report, report_dir):
    """Atomically replace the private in-progress checkpoint (not a .json report)."""
    directory = Path(report_dir).expanduser().absolute()
    target = directory/CHECKPOINT_NAME
    temporary = directory/(CHECKPOINT_NAME + '.new-' + str(os.getpid()))
    fd = os.open(str(temporary), os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(report, stream)
        os.replace(str(temporary), str(target))
    finally:
        if temporary.exists():
            temporary.unlink()


def write_report(report, args, root):
    try:
        emit_json_report(report, args.report_dir, root)
    except (OSError, ValueError) as exc:
        print('Report output error: %s' % exc, file=sys.stderr)
        return 2
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--duration', type=positive, default=600, help='observation seconds (default 600)')
    parser.add_argument('--interval', type=positive, default=60, help='seconds between scan starts (default 60)')
    parser.add_argument('--active-glob', action='append', help='repeatable file pattern to measure, matched against relative path OR basename; default all non-archive files')
    parser.add_argument('--max-depth', type=nonnegative, help='0 = top-level only; default recursive')
    parser.add_argument('--top', type=nonnegative, default=10, help='largest files listed in the inventory')
    parser.add_argument('--baseline', action='store_true', help='setup snapshot: inventory, system info and rotation/cron evidence; no growth sampling')
    parser.add_argument('--include-policy-configs', action='store_true', help='embed selected configuration text in the setup snapshot, unredacted; review for secrets before sharing')
    parser.add_argument('--sample-label', default=None, help='label recorded in the report, e.g. setup_inventory, initial_baseline, normal')
    parser.add_argument('--cleanup-script', action='append', default=[], help='explicit cleanup script to read as text, never execute; repeatable')
    parser.add_argument('--target-file-age-hours', type=positive, help='operator target for maximum file age, hours')
    parser.add_argument('--candidate-size-gb', type=positive, help='operator proposed size ceiling, decimal GB')
    parser.add_argument('--recovery-hours', type=positive, help='operator required recovery window, hours')
    parser.add_argument('--disk-budget-gb', type=positive, help='operator available budget after reserved headroom, decimal GB')
    parser.add_argument('--cron-file', action='append', default=[], help='additional absolute cron/exported-crontab file, repeatable; read only')
    parser.add_argument('--report-dir', type=Path, help='write a private timestamped JSON report here, outside the monitored directory')
    parser.add_argument('--checkpoint-seconds', type=positive, help='save in-progress measurements to the report directory this often, so an interrupted run can still be reported')
    parser.add_argument('--logrotate-config', default='/etc/logrotate.conf', help='logrotate root config or directory')
    parser.add_argument('--rsyslog-config', default='/etc/rsyslog.conf', help='rsyslog root config')
    parser.add_argument('--syslog-ng-config', default='/etc/syslog-ng/syslog-ng.conf', help='syslog-ng root config')
    args = parser.parse_args()
    root = args.directory.expanduser().resolve()
    if not root.is_dir():
        parser.error('directory must be an existing directory')
    for path in args.cron_file:
        if not Path(path).is_absolute():
            parser.error('--cron-file requires absolute paths')
    if args.report_dir and os.path.commonpath([str(args.report_dir.expanduser().resolve()), str(root)]) == str(root):
        parser.error('--report-dir must be outside the monitored log directory')
    if args.sample_label and not re.fullmatch(r'[A-Za-z0-9_-]{1,32}', args.sample_label):
        parser.error('--sample-label must contain 1-32 letters, digits, underscores or hyphens')

    if args.baseline:
        from syslog_evidence import collect_system_info, collect_rotation_timer_status
        files, scan_errors, seconds, links = scan(root, args.max_depth)
        if not files and scan_errors:
            print('Unable to inventory files: ' + scan_errors[0], file=sys.stderr)
            return 2
        cron_report = collect_cron_policies(args.include_policy_configs, args.cron_file)
        cron_report['logrotate_timer_status'] = collect_rotation_timer_status()
        report = {'schema_version': '2.3', 'hostname': socket.gethostname(), 'sample_label': args.sample_label,
                  'mode': 'baseline', 'assessment_scope': 'syslog_only',
                  'collected_utc': datetime.now(timezone.utc).isoformat(),
                  'directory': str(root), 'system_info': collect_system_info(),
                  'final_inventory': inventory(files, links, root, args.top, include_files=True),
                  'policies': collect_policies(args.logrotate_config, args.rsyslog_config, args.syslog_ng_config, args.include_policy_configs),
                  'cron_policies': cron_report,
                  'assessment_objectives': {'target_file_age_hours': args.target_file_age_hours, 'candidate_size_gb': args.candidate_size_gb,
                                            'recovery_hours': args.recovery_hours, 'disk_budget_gb': args.disk_budget_gb},
                  'cleanup_scripts': collect_cleanup_scripts(args.cleanup_script),
                  'scan': {'maximum_seconds': seconds, 'error_count': len(scan_errors), 'error_examples': scan_errors[:10]},
                  'warnings': ['Setup snapshot only; no fill-rate sampling.',
                               'Installed versions do not establish running service versions.',
                               'Policies are declarations; actual retention and deletion behavior need independent review.',
                               'Logical file sizes are not allocated disk usage; age is not configured retention.']}
        if scan_errors:
            report['warnings'].append('Scan errors occurred; inventory is incomplete.')
        return write_report(report, args, root)

    patterns = args.active_glob or ['*']
    warnings = [
        'File-growth measurement uses metadata only; it does not measure EPS, Cribl capacity or delivery.',
        'Growth is a lower-bound estimate from positive size deltas of the same inode between scans.',
        'New-file initial bytes and post-truncation bytes are reported separately, not included in growth rates.',
        'Writes followed by truncation/deletion between scans can be missed; inode reuse may not be detected.',
        'Compressed/archive files are included in inventory but excluded from growth measurements.',
        'Modification-age bands are NOT proof of the configured retention policy.',
        'Averages and peaks describe this observation only; daily numbers are extrapolations, not forecasts.']
    if not args.active_glob:
        warnings.append('No file pattern supplied: all non-archive regular files contribute to growth.')
    previous, errors, scan_seconds, links = scan(root, args.max_depth)
    if not previous and errors:
        print('Unable to inventory files: ' + errors[0], file=sys.stderr)
        return 2
    baseline = inventory(previous, links, root, args.top)
    errors_count, error_examples = len(errors), errors[:10]
    scan_times = [scan_seconds]
    start = last = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    cumulative, peaks = {}, {}
    active_paths = {choose_active(row, patterns) for row in previous.values()}
    active_paths.discard(None)
    intervals = []
    new_count = new_bytes = trunc_count = trunc_bytes = gone_count = path_changes_total = 0
    def build_report():
        elapsed = last - start
        notes = list(warnings)
        total = sum(cumulative.values())
        avg = total / elapsed
        per_file = [{'path': name, 'observed_growth_bytes': cumulative.get(name, 0),
                     'average_MB_per_second': cumulative.get(name, 0) / elapsed / 1e6,
                     'peak_sample_MB_per_second': peaks.get(name, 0) / 1e6,
                     'extrapolated_GB_per_day': cumulative.get(name, 0) / elapsed * DAY / 1e9}
                    for name in sorted(active_paths)]
        if new_count or trunc_count or gone_count or path_changes_total:
            notes.append('FILE CHURN OBSERVED: rates can be understated. Use shorter intervals and compare with syslog-writer byte counters; do not size production from this report alone.')
        if max(scan_times) >= args.interval:
            notes.append('Scanning took at least one full interval. Narrow directory/depth; peak rates are low-resolution and scanning may add load.')
        if errors_count:
            notes.append('Scan errors occurred; inventory and rates are incomplete.')
        peak = max(r['growth_MB_per_second'] for r in intervals)
        report = {'schema_version': '2.3', 'hostname': socket.gethostname(), 'sample_label': args.sample_label,
                  'mode': 'growth', 'assessment_scope': 'syslog_only',
                  'started_utc': started, 'directory': str(root), 'active_globs': patterns,
                  'completed_observation_seconds': elapsed, 'completed_samples': len(intervals),
                  'configured_interval_seconds': args.interval,
                  'initial_inventory': baseline,
                  'final_inventory': inventory(previous, links, root, args.top, include_files=True),
                  'growth': {'same_inode_growth_bytes': total, 'average_MB_per_second': avg / 1e6,
                             'peak_sample_MB_per_second': peak,
                             'extrapolated_TB_per_day': avg * DAY / 1e12,
                             'newly_observed_file_count': new_count,
                             'newly_observed_bytes_excluded_from_rate': new_bytes,
                             'truncation_count': trunc_count,
                             'post_truncation_bytes_excluded_from_rate': trunc_bytes,
                             'disappeared_file_count': gone_count, 'observed_path_change_count': path_changes_total},
                  'per_active_path': sorted(per_file, key=lambda r: r['average_MB_per_second'], reverse=True),
                  'intervals': intervals,
                  'scan': {'maximum_seconds': max(scan_times), 'error_count': errors_count, 'error_examples': error_examples},
                  'warnings': notes}
        return report

    last_checkpoint = time.monotonic()
    try:
        while time.monotonic() - start < args.duration:
            target = min(last + args.interval, start + args.duration)
            time.sleep(max(0, target - time.monotonic()))
            current, errors, seconds, links = scan(root, args.max_depth)
            now = time.monotonic()
            dt = now - last
            path_changes = find_path_changes(previous, current)
            path_changes_total += len(path_changes)
            growth, nc, nb, tc, tb, gc = compare(previous, current, patterns)
            for name, count in growth.items():
                cumulative[name] = cumulative.get(name, 0) + count
                peaks[name] = max(peaks.get(name, 0), count / dt)
            active_paths.update(filter(None, (choose_active(r, patterns) for r in current.values())))
            intervals.append({'elapsed_seconds': now - start, 'interval_seconds': dt,
                              'same_inode_growth_bytes': sum(growth.values()),
                              'growth_MB_per_second': sum(growth.values()) / dt / 1e6,
                              'unique_regular_file_count': len(current),
                              'logical_file_bytes': sum(row['size'] for row in current.values()),
                              'largest_file_bytes': max((row['size'] for row in current.values()), default=0),
                              'scan_seconds': seconds, 'scan_error_count': len(errors),
                              'new_file_count': nc, 'truncation_count': tc, 'disappeared_file_count': gc,
                              'path_change_count': len(path_changes), 'path_change_examples': path_changes[:20]})
            new_count += nc; new_bytes += nb
            trunc_count += tc; trunc_bytes += tb; gone_count += gc
            errors_count += len(errors)
            error_examples.extend(errors[:max(0, 10 - len(error_examples))])
            scan_times.append(seconds)
            previous, last = current, now
            if args.checkpoint_seconds and args.report_dir and now - last_checkpoint >= args.checkpoint_seconds:
                try:
                    write_checkpoint(dict(build_report(), checkpoint=True), args.report_dir)
                except OSError as exc:
                    print('Checkpoint write failed: %s' % exc, file=sys.stderr)
                last_checkpoint = now
            print('Sample %d: %.3f MB/sec; new files=%d; truncations=%d; disappeared=%d' %
                  (len(intervals), intervals[-1]['growth_MB_per_second'], nc, tc, gc), file=sys.stderr)
    except KeyboardInterrupt:
        print('\nStopped; reporting completed samples only.', file=sys.stderr)
    elapsed = last - start
    if not intervals or elapsed <= 0:
        print('No completed samples; run longer than one scan interval.', file=sys.stderr)
        return 2
    return write_report(build_report(), args, root)


if __name__ == '__main__':
    sys.exit(main())
