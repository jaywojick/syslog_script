#!/usr/bin/env python3
"""Continuous syslog fill-rate assessment: guided setup, background run, status, stop, finish.

No cron, service or system configuration is changed. The measurement runs as a
background process owned by the account that started it.

  python3 syslog_runner.py status --config <session>/assessment.json
  python3 syslog_runner.py stop   --config <session>/assessment.json
  python3 syslog_runner.py finish --config <session>/assessment.json
  python3 syslog_runner.py start  --config <session>/assessment.json
"""
import argparse
from datetime import datetime, timezone, timedelta
import fcntl
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time

from syslog_menu import ui_input
from syslog_evidence import parse_iso_datetime

HERE = Path(__file__).resolve().parent
SCHEMA = 2
DEFAULT_CRIBL_RATE_MB_SEC = 2.4
CHECKPOINT_SECONDS = 900
STATE_NAME = 'assessment_state.json'
LOG_NAME = 'assessment.log'


def utc_now():
    return datetime.now(timezone.utc)


def parse_time(value):
    value = value.strip()
    if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d', value):
        raise ValueError('Use 24-hour HH:MM, e.g. 12:00, or press Enter to start now.')
    return value


def private_directory(path):
    path = Path(path).expanduser().absolute()
    path.mkdir(parents=True, mode=0o700, exist_ok=True)
    mode = path.lstat().st_mode
    if not stat.S_ISDIR(mode) or stat.S_ISLNK(mode) or mode & 0o077:
        raise ValueError('Report directory must be a real private directory (0700)')
    return path


def option(command, flag):
    try:
        return command[command.index(flag) + 1]
    except (ValueError, IndexError):
        raise ValueError('Assessment command requires ' + flag)


def validate_config(config):
    if config.get('schema_version') != SCHEMA:
        raise ValueError('Unsupported assessment configuration; create a new assessment with this package.')
    command = config.get('command')
    if not isinstance(command, list) or len(command) < 3 or any(not isinstance(x, str) for x in command):
        raise ValueError('Assessment must contain a collector argument list')
    if any(any(char in x for char in ('\n', '\r', '\x00')) for x in command):
        raise ValueError('Newlines/NUL are not allowed in assessment arguments')
    if Path(command[0]).resolve() != Path(sys.executable).resolve() or Path(command[1]).resolve() != HERE/'syslog_sizing.py':
        raise ValueError('Assessment must invoke this package collector with the current Python executable')
    if not Path(command[2]).is_dir():
        raise ValueError('Monitored log directory does not exist')
    if '--baseline' in command or '--sample-label' in command:
        raise ValueError('Continuous command must be a growth measurement without a preset label')
    report_dir = Path(config.get('report_dir', '')).absolute()
    if command.count('--report-dir') != 1 or option(command, '--report-dir') != str(report_dir):
        raise ValueError('Report directory does not match the assessment command')
    root = Path(command[2]).resolve()
    if os.path.commonpath([str(report_dir.resolve()), str(root)]) == str(root):
        raise ValueError('Reports must be outside the monitored log directory')
    for flag in ('--interval',):
        number = float(option(command, flag))
        if not math.isfinite(number) or number <= 0:
            raise ValueError('Invalid scan interval')
    hours = config.get('runtime_hours')
    if isinstance(hours, bool) or not isinstance(hours, (int, float)) or not math.isfinite(hours) or hours <= 0:
        raise ValueError('Invalid runtime hours')
    try:
        start = parse_iso_datetime(config['start_utc'])
        if start.tzinfo is None:
            raise ValueError()
    except (KeyError, TypeError, ValueError):
        raise ValueError('Invalid planned start time')
    rate = config.get('cribl_rate_MB_per_second', DEFAULT_CRIBL_RATE_MB_SEC)
    if isinstance(rate, bool) or not isinstance(rate, (int, float)) or not math.isfinite(rate) or rate <= 0:
        raise ValueError('Invalid Cribl ingestion rate')
    checkpoint = config.get('checkpoint_seconds', CHECKPOINT_SECONDS)
    if isinstance(checkpoint, bool) or not isinstance(checkpoint, (int, float)) or not math.isfinite(checkpoint) or checkpoint <= 0:
        raise ValueError('Invalid checkpoint interval')
    return config


def write_private_json(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + '.new-' + str(os.getpid()))
    fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, indent=2)
            stream.write('\n')
        if path.is_symlink():
            raise ValueError('Refusing to replace a symlink: ' + str(path))
        os.replace(str(temporary), str(path))
    finally:
        if temporary.exists():
            temporary.unlink()


def read_private_json(path, limit=1024 * 1024):
    fd = os.open(str(path), os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    with os.fdopen(fd, 'r', encoding='utf-8') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077 or info.st_size > limit:
            raise ValueError('Expected a private regular file (0600): ' + str(path))
        return json.loads(stream.read())


def save_config(path, config):
    validate_config(config)
    private_directory(Path(path).parent)
    write_private_json(path, config)
    return Path(path).absolute()


def load_config(path):
    return validate_config(read_private_json(Path(path).absolute()))


def state_path(config):
    return Path(config['report_dir'])/STATE_NAME


def read_state(config):
    path = state_path(config)
    return read_private_json(path) if path.exists() else {}


def write_state(config, state):
    write_private_json(state_path(config), state)


def acquire_lock(lock, wait_seconds=0, poll_seconds=0.2):
    """Take the exclusive run lock, retrying for up to wait_seconds."""
    deadline = time.monotonic() + wait_seconds
    while True:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:
            if time.monotonic() >= deadline:
                return False
            time.sleep(poll_seconds)


def open_lock(config):
    fd = os.open(str(Path(config['report_dir'])/'collector.lock'), os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    return os.fdopen(fd, 'r+')


def pid_alive(pid):
    if not isinstance(pid, int) or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def run_growth_reports(config, since_utc=None):
    """Continuous measurement reports written in this session, oldest first."""
    rows = []
    for path in Path(config['report_dir']).glob('syslog_*_continuous*.json'):
        try:
            data = read_private_json(path, 64 * 1024 * 1024)
        except (OSError, ValueError):
            continue
        if data.get('mode') == 'growth' and (since_utc is None or str(data.get('started_utc', '')) >= since_utc):
            rows.append((str(data.get('started_utc', '')), path, data))
    return sorted(rows)


def finalize(config, state, complete, reason):
    """Combine the setup snapshot and continuous measurement into the final report."""
    from syslog_assessment_report import build_summary
    from syslog_sizing import emit_json_report
    report_dir = Path(config['report_dir'])
    summary = build_summary(report_dir, cribl_rate=config.get('cribl_rate_MB_per_second', DEFAULT_CRIBL_RATE_MB_SEC))
    summary['sample_label'] = 'final_assessment'
    run = {'observation_mode': 'continuous', 'runtime_hours': config['runtime_hours'],
           'scan_interval_seconds': float(option(config['command'], '--interval')),
           'file_patterns': config.get('file_patterns') or ['all non-archive files'],
           'planned_start_utc': config['start_utc'], 'started_utc': state.get('started_utc'),
           'ended_utc': utc_now().isoformat(), 'completed_as_planned': bool(complete), 'note': reason}
    summary['assessment_run'] = run
    for server in summary['servers']:
        server['assessment_run'] = run
        if not complete:
            gap = 'Continuous observation did not complete as planned: ' + reason
            server['evidence_gaps'].append(gap)
            server.setdefault('blocking_gaps', []).append(gap)
            if server.get('rotation_proposal'):
                server['rotation_proposal']['status'] = 'INSUFFICIENT_EVIDENCE'
                server['rotation_proposal'].setdefault('blocking_gaps', []).append(gap)
            if server.get('evidence_assessment'):
                server['evidence_assessment']['status'] = 'INSUFFICIENT_EVIDENCE'
    if not complete:
        summary['errors'].append({'error': 'Continuous observation did not complete as planned: ' + reason})
        summary['common_policy'] = {'status': 'INSUFFICIENT_EVIDENCE', 'reason': 'Continuous observation did not complete as planned.'}
    output = emit_json_report(summary, report_dir)
    state.update(status='completed' if complete else 'incomplete', completed_utc=utc_now().isoformat(),
                 final_report=str(output), final_summary=str(output.with_suffix('.txt')), note=reason)
    write_state(config, state)
    print('%s Final report: %s' % (utc_now().isoformat(), output.with_suffix('.txt')), flush=True)
    return output


def recover_checkpoint(config, state):
    """If the measurement process died, turn its last checkpoint into a partial report."""
    from syslog_sizing import CHECKPOINT_NAME, emit_json_report
    checkpoint = Path(config['report_dir'])/CHECKPOINT_NAME
    if run_growth_reports(config, state.get('started_utc')) or not checkpoint.exists():
        return None
    data = read_private_json(checkpoint, 256 * 1024 * 1024)
    data.pop('checkpoint', None)
    data['sample_label'] = 'continuous_partial'
    data.setdefault('warnings', []).append('Recovered from the last in-progress checkpoint after the run was interrupted; later measurements were lost.')
    return emit_json_report(data, config['report_dir'])


def run(config_path):
    """Background process: wait for the start time, measure, then write the final report."""
    config = load_config(config_path)
    report_dir = private_directory(config['report_dir'])
    with open_lock(config) as lock:
        if not acquire_lock(lock, 0):
            print('Assessment is already running for this session.', flush=True)
            return 0
        state = read_state(config)
        if state.get('status') in ('completed', 'incomplete', 'stopped'):
            print('Assessment already finished: ' + state['status'], flush=True)
            return 0
        flags = {'stop': False}
        child = {'process': None}

        def on_signal(signum, frame):
            flags['stop'] = True
            process = child['process']
            if process is not None and process.poll() is None:
                process.send_signal(signal.SIGINT)  # collector writes what it measured

        signal.signal(signal.SIGTERM, on_signal)
        signal.signal(signal.SIGINT, on_signal)
        signal.signal(signal.SIGHUP, signal.SIG_IGN)
        start = parse_iso_datetime(config['start_utc'])
        state = {'status': 'waiting', 'pid': os.getpid(), 'planned_start_utc': config['start_utc'],
                 'launched_utc': utc_now().isoformat()}
        write_state(config, state)
        print('%s Waiting for planned start %s' % (utc_now().isoformat(), config['start_utc']), flush=True)
        while not flags['stop'] and utc_now() < start:
            time.sleep(min(30.0, max(0.1, (start - utc_now()).total_seconds())))
        if flags['stop']:
            finalize(config, state, False, 'Stopped before measurement started.')
            state['status'] = 'stopped'
            write_state(config, state)
            return 0
        began = utc_now()
        seconds = float(config['runtime_hours']) * 3600
        state.update(status='running', started_utc=began.isoformat(),
                     expected_end_utc=(began + timedelta(seconds=seconds)).isoformat())
        write_state(config, state)
        print('%s Continuous measurement started; expected end %s' % (began.isoformat(), state['expected_end_utc']), flush=True)
        command = list(config['command']) + ['--duration', str(seconds), '--sample-label', 'continuous',
                                             '--checkpoint-seconds', str(config.get('checkpoint_seconds', CHECKPOINT_SECONDS))]
        child['process'] = subprocess.Popen(command, stdin=subprocess.DEVNULL)
        code = child['process'].wait()
        reports = run_growth_reports(config, state['started_utc'])
        interval = float(option(config['command'], '--interval'))
        actual = float(reports[-1][2].get('completed_observation_seconds') or 0) if reports else 0.0
        complete = code == 0 and not flags['stop'] and actual >= seconds - max(2 * interval, 30)
        if complete:
            reason = 'Completed %.1f of %.1f planned hours.' % (actual / 3600, seconds / 3600)
        elif flags['stop']:
            reason = 'Stopped by operator after %.1f of %.1f planned hours.' % (actual / 3600, seconds / 3600)
        else:
            reason = 'Measurement process ended early (exit %s) after %.1f of %.1f planned hours.' % (code, actual / 3600, seconds / 3600)
        finalize(config, state, complete, reason)
        if flags['stop']:
            state['status'] = 'stopped'
            write_state(config, state)
        return 0 if complete else 1


def launch(config_path):
    """Start the background runner, detached from this terminal session."""
    config = load_config(config_path)
    state = read_state(config)
    if state.get('status') in ('waiting', 'running') and pid_alive(state.get('pid')):
        raise ValueError('This assessment is already running (process %s).' % state.get('pid'))
    if state.get('status') in ('completed', 'incomplete', 'stopped'):
        raise ValueError('This assessment has finished; run setup again for a new assessment.')
    log = Path(config['report_dir'])/LOG_NAME
    fd = os.open(str(log), os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    with os.fdopen(fd, 'a') as stream:
        process = subprocess.Popen([sys.executable, str(HERE/'syslog_runner.py'), 'run', '--config', str(Path(config_path).absolute())],
                                   stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
                                   cwd=str(config['report_dir']), start_new_session=True)
    for _ in range(50):
        if read_state(config).get('pid') == process.pid or process.poll() is not None:
            break
        time.sleep(0.1)
    if process.poll() not in (None, 0):
        raise ValueError('Assessment process failed to start; see ' + str(log))
    return process.pid


def last_progress_line(config):
    log = Path(config['report_dir'])/LOG_NAME
    try:
        with open(str(log), 'rb') as stream:
            stream.seek(max(0, log.stat().st_size - 65536))
            lines = [l for l in stream.read().decode('utf-8', 'replace').splitlines() if l.strip()]
        samples = [l for l in lines if l.startswith('Sample ')]
        return (samples or lines or [None])[-1]
    except OSError:
        return None


def show_status(config_path):
    config = load_config(config_path)
    state = read_state(config)
    status = state.get('status', 'not started')
    alive = pid_alive(state.get('pid'))
    print('Assessment: ' + str(config['report_dir']))
    print('Status: ' + status + ('' if status not in ('waiting', 'running') else
                                 ' (process %s %s)' % (state.get('pid'), 'running' if alive else 'NOT RUNNING')))
    for key, label in [('planned_start_utc', 'Planned start UTC'), ('started_utc', 'Started UTC'),
                       ('expected_end_utc', 'Expected end UTC'), ('completed_utc', 'Finished UTC'),
                       ('note', 'Result'), ('final_summary', 'Final summary')]:
        if state.get(key):
            print('%-18s %s' % (label + ':', state[key]))
    progress = last_progress_line(config)
    if progress and status in ('waiting', 'running'):
        print('Latest progress:   ' + progress)
    if status in ('waiting', 'running') and not alive:
        print('The background process is no longer running (for example after a restart).')
        print('Run "finish" to write a report from the last 15-minute checkpoint, then start a new assessment if needed.')
    return 0


def stop(config_path, wait_seconds=120):
    config = load_config(config_path)
    state = read_state(config)
    pid = state.get('pid')
    if state.get('status') not in ('waiting', 'running') or not pid_alive(pid):
        print('No running assessment process for this session.')
        return 1
    os.kill(pid, signal.SIGTERM)
    print('Stop requested. Writing the measurements collected so far and the final report...')
    deadline = time.monotonic() + wait_seconds
    while time.monotonic() < deadline:
        current = read_state(config)
        if current.get('final_summary'):
            print('Final summary: ' + current['final_summary'])
            return 0
        time.sleep(1)
    print('Still finishing; check again with "status".')
    return 0


def finish(config_path):
    """Write a final report for a run whose background process is gone."""
    config = load_config(config_path)
    with open_lock(config) as lock:
        if not acquire_lock(lock, 0):
            print('The assessment is still running; use "stop" to end it early.')
            return 1
        state = read_state(config)
        if state.get('final_summary') and state.get('status') in ('completed', 'incomplete', 'stopped'):
            print('Final summary already written: ' + state['final_summary'])
            return 0
        recovered = recover_checkpoint(config, state) if state.get('started_utc') else None
        if recovered:
            reason = 'Run was interrupted; report built from the last checkpoint.'
        elif state.get('started_utc'):
            reason = 'Run was interrupted before any checkpoint was saved.'
        else:
            reason = 'Measurement never started.'
        finalize(config, state, False, reason)
        return 0


def prompt_patterns(directory):
    """Ask which files to measure and confirm that the patterns match something now."""
    from syslog_sizing import scan, active
    print('File patterns: which files to measure for growth, matched against the file name or relative path (for example *.log).')
    print('Compressed archives are always excluded. Press Enter to measure all files.')
    files, _, _, _ = scan(Path(directory), None)
    names = [name for row in files.values() for name in row['paths']]
    while True:
        value = ui_input('File name patterns to measure, comma-separated [all files]: ')
        patterns = list(dict.fromkeys(p.strip() for p in value.split(',') if p.strip()))
        if any(any(c in p for c in ('\n', '\r', '\x00')) for p in patterns) or len(patterns) > 20:
            print('Enter up to 20 patterns without control characters.')
            continue
        matched = sum(active(name, patterns or ['*']) for name in names)
        print('Matched %d of %d files currently in the directory.' % (matched, len(names)))
        if matched or not names:
            return patterns
        print('No current files match; check the patterns or press Enter for all files.')


def glob_arguments(patterns):
    result = []
    for pattern in patterns or []:
        result += ['--active-glob', pattern]
    return result


def planned_start(value, now=None):
    """Next local occurrence of HH:MM (today or tomorrow), or now when blank."""
    now = now or datetime.now().astimezone()
    if not value:
        return now
    hour, minute = map(int, parse_time(value).split(':'))
    start = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if start <= now:
        start += timedelta(days=1)
    return start


def latest_setup_snapshot(report_dir):
    paths = sorted(Path(report_dir).glob('syslog_*_setup_inventory.json'))
    return read_private_json(paths[-1], 256 * 1024 * 1024) if paths else None


def configure_syslog_assessment():
    from syslog_menu import prompt_path, prompt_seconds, optional_files, optional_positive
    print('Choose the directory containing the syslog files to assess; metadata is read, not log contents.')
    directory = prompt_path('Syslog file directory', directory=True, must_exist=True)
    patterns = prompt_patterns(directory)
    print('Reports are saved here; choose a location outside the syslog directory.')
    parent = prompt_path('Assessment output parent directory (outside log directory)', str(Path.home()/'cvs-syslog-reports'), directory=True)
    report_dir = parent/('assessment_' + utc_now().strftime('%Y%m%dT%H%M%S_%fZ'))
    if os.path.commonpath([str(report_dir.resolve()), str(directory.resolve())]) == str(directory.resolve()):
        raise ValueError('Assessment output must be outside the monitored log directory')
    print('Optional: supply exported crontabs that show existing rotation or cleanup schedules.')
    cron_files = optional_files('Optional exported rotation crontab file')
    print('Raw cron/config text can reveal commands and secrets; reports are unredacted.')
    raw_policy = ui_input('Include raw rotation and cron configuration text? [y/N]: ').strip().lower() in ('y', 'yes')
    print('Selected cleanup scripts are read as text, never executed. Reports include their UNREDACTED contents; review before sharing.')
    cleanup_files = optional_files('Custom cleanup script to collect')
    print('Enter known tuning objectives; press Enter if unknown. No rotation size or interval is preset.')
    print('File age: desired maximum time before a time-based rotation if the size limit is not reached.')
    age = optional_positive('Maximum desired file age in hours')
    print('File size: optional upper bound in decimal GB for the calculated size candidate.')
    size = optional_positive('Candidate maximum file size in decimal GB')
    print('Recovery window: how long logs may need to be retained for interruption and recovery.')
    recovery = optional_positive('Required recovery window in hours')
    print('Retention budget: space available for retained logs after reserving operational headroom.')
    budget = optional_positive('Usable retention budget after disk headroom in decimal GB')
    print('Cribl ingestion rate: the rate Cribl can read from ALL servers combined. Combined fill rates above it would queue.')
    rate = float(prompt_seconds('Cribl ingestion rate shared by all servers, MB/sec', str(DEFAULT_CRIBL_RATE_MB_SEC)))
    print('Continuous measurement: file sizes are checked every scan interval for the whole runtime.')
    hours = prompt_seconds('Continuous runtime hours', '24')
    interval = prompt_seconds('Seconds between file metadata scans', '60', 's')
    if float(interval) >= float(hours) * 3600:
        raise ValueError('Runtime must be longer than the scan interval.')
    print('Server clock: ' + datetime.now().astimezone().strftime('%Y-%m-%d %H:%M %Z %z'))
    print('For a combined fleet result, run every server over the same period (use the same start time).')
    while True:
        try:
            start = planned_start(ui_input('Start time, local HH:MM (Enter to start immediately): ').strip())
            break
        except ValueError as exc:
            print(str(exc))

    print('\nCollecting the setup snapshot: file inventory, versions, resources and existing rotation/retention/cron evidence.')
    static_command = [sys.executable, str(HERE/'syslog_sizing.py'), str(directory),
                      '--baseline', '--sample-label', 'setup_inventory', '--report-dir', str(report_dir)]
    if raw_policy:
        static_command.append('--include-policy-configs')
    for exported in cron_files:
        static_command += ['--cron-file', str(exported)]
    for cleanup in cleanup_files:
        static_command += ['--cleanup-script', str(cleanup)]
    for flag, value in [('--target-file-age-hours', age), ('--candidate-size-gb', size), ('--recovery-hours', recovery), ('--disk-budget-gb', budget)]:
        if value:
            static_command += [flag, value]
    if subprocess.run(static_command, stdin=subprocess.DEVNULL, check=False, timeout=300).returncode:
        raise ValueError('Setup snapshot failed; nothing was started. Review the errors above.')
    snapshot = latest_setup_snapshot(report_dir) or {}
    inv, scan_info = snapshot.get('final_inventory') or {}, snapshot.get('scan') or {}
    scan_seconds = float(scan_info.get('maximum_seconds') or 0)
    print('Setup snapshot saved: %s files, %.2f GB; one full scan took %.2f s.'
          % (inv.get('unique_regular_files', '?'), (inv.get('logical_bytes') or 0) / 1e9, scan_seconds))
    if scan_seconds >= float(interval) / 2:
        print('WARNING: a scan takes at least half the scan interval. Narrow the directory or lengthen the interval.')

    command = [sys.executable, str(HERE/'syslog_sizing.py'), str(directory), '--interval', interval,
               '--report-dir', str(report_dir)] + glob_arguments(patterns)
    config = {'schema_version': SCHEMA, 'command': command, 'report_dir': str(report_dir),
              'runtime_hours': float(hours), 'start_utc': start.astimezone(timezone.utc).isoformat(),
              'start_local': start.strftime('%Y-%m-%d %H:%M %Z'), 'file_patterns': patterns,
              'cribl_rate_MB_per_second': rate, 'created_utc': utc_now().isoformat()}
    path = save_config(report_dir/'assessment.json', config)
    end = start + timedelta(hours=float(hours))
    print('\nCONTINUOUS ASSESSMENT PLAN')
    print('Log directory:     ' + str(directory))
    print('Files measured:    ' + (', '.join(patterns) if patterns else 'all non-archive files'))
    print('Start (local):     ' + ('immediately' if not (start - datetime.now().astimezone()).total_seconds() > 1 else start.strftime('%Y-%m-%d %H:%M %Z')))
    print('Runs for:          %s hours, scanning every %s seconds (ends about %s)' % (hours, interval, end.strftime('%Y-%m-%d %H:%M %Z')))
    print('Cribl rate:        %s MB/sec shared by all servers' % rate)
    print('Reports:           ' + str(report_dir))
    print('No cron entries, services or system settings are changed. The run is a background process for this account;')
    print('it keeps running after you log out. A restart stops it; progress is checkpointed every 15 minutes.')
    if ui_input('Start the continuous assessment now? [y/N]: ').strip().lower() in ('y', 'yes'):
        pid = launch(path)
        print('Started in the background (process %d).' % pid)
    else:
        print('Not started. Start later with:')
        print('  python3 %s start --config %s' % (HERE/'syslog_runner.py', path))
    print('Check progress:  python3 %s status --config %s' % (HERE/'syslog_runner.py', path))
    print('Stop early:      python3 %s stop --config %s' % (HERE/'syslog_runner.py', path))
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('action', choices=['setup', 'start', 'run', 'status', 'stop', 'finish'])
    parser.add_argument('--config', type=Path, help='assessment.json in the session folder')
    args = parser.parse_args()
    if args.action != 'setup' and args.config is None:
        parser.error('--config is required')
    try:
        if args.action == 'setup':
            configure_syslog_assessment()
        elif args.action == 'start':
            print('Started in the background (process %d).' % launch(args.config))
        elif args.action == 'run':
            return run(args.config)
        elif args.action == 'status':
            return show_status(args.config)
        elif args.action == 'stop':
            return stop(args.config)
        else:
            return finish(args.config)
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        print('Assessment error: ' + str(exc), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (EOFError, KeyboardInterrupt):
        print('\nAssessment setup closed.', file=sys.stderr)
        sys.exit(130)
