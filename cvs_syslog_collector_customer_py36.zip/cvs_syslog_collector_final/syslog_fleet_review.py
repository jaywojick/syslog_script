#!/usr/bin/env python3
"""Central review of the final reports collected from each syslog server. Local files only; no network access."""
import argparse
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True

from syslog_assessment_report import DEFAULT_CRIBL_RATE_MB_SEC, build_summary, render_brief


def load_expected_servers(path):
    path = Path(path)
    if path.stat().st_size > 1024 * 1024:
        raise ValueError('Expected-server list exceeds 1 MiB')
    hosts = []
    for line in path.read_text().splitlines():
        value = line.strip()
        if not value or value.startswith('#'):
            continue
        if any(char.isspace() for char in value):
            raise ValueError('Use one exact recorded hostname per line in the server list')
        if value not in hosts:
            hosts.append(value)
    if not hosts:
        raise ValueError('Expected-server list is empty')
    return hosts


def rate_value(text):
    value = float(text)
    if not math.isfinite(value) or value <= 0:
        raise ValueError('The Cribl ingestion rate must be a positive number')
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reports_root', nargs='?', type=Path, help='folder containing the reports from all servers; searched recursively')
    parser.add_argument('--output-dir', type=Path, help='private JSON/text review destination; default sibling fleet-review-output')
    parser.add_argument('--expected-servers-file', type=Path, help='optional text roster: one exact recorded hostname per line')
    parser.add_argument('--cribl-rate', type=float, help='Cribl ingestion rate shared by all servers, MB/sec (default %s)' % DEFAULT_CRIBL_RATE_MB_SEC)
    args = parser.parse_args()
    if args.reports_root is None:
        if not sys.stdin.isatty():
            parser.error('reports_root is required outside an interactive terminal')
        from syslog_menu import prompt_path, prompt_seconds, ui_input
        print('CENTRAL SYSLOG FLEET REVIEW - collected reports only; no server connections')
        args.reports_root = prompt_path('Root folder containing all server reports', directory=True, must_exist=True)
        if args.output_dir is None:
            args.output_dir = prompt_path('Private fleet-review output directory', str(args.reports_root.parent/'fleet-review-output'), directory=True)
        if args.expected_servers_file is None:
            value = ui_input('Optional expected-server text list (Enter to skip): ').strip()
            args.expected_servers_file = Path(value).expanduser() if value else None
        if args.cribl_rate is None:
            args.cribl_rate = float(prompt_seconds('Cribl ingestion rate shared by all servers, MB/sec', str(DEFAULT_CRIBL_RATE_MB_SEC)))
    root = args.reports_root.expanduser().absolute()
    output = args.output_dir.expanduser().absolute() if args.output_dir else root.parent/'fleet-review-output'
    try:
        if not root.is_dir():
            raise ValueError('Collected report root does not exist')
        rate = rate_value(args.cribl_rate if args.cribl_rate is not None else DEFAULT_CRIBL_RATE_MB_SEC)
        expected = load_expected_servers(args.expected_servers_file) if args.expected_servers_file else None
        result = build_summary(root, expected, output, cribl_rate=rate)
        result['sample_label'] = 'fleet_review'
        from syslog_sizing import emit_json_report
        emit_json_report(result, output)
        print(render_brief(result))
        print('Review complete. Source files are unchanged. No configuration settings were applied.')
        return 0 if result['servers'] else 2
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print('Fleet review error: ' + str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (EOFError, KeyboardInterrupt):
        print('\nFleet review stopped.', file=sys.stderr)
        raise SystemExit(130)
