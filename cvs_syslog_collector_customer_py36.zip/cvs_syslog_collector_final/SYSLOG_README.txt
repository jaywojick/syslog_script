SYSLOG FILE ASSESSMENT — CONTINUOUS FILL-RATE MEASUREMENT

Purpose
  Measure how fast syslog files grow on each syslog-ng / rsyslog server, compare
  the combined rate of all servers with the Cribl ingestion rate (2.4 MB/sec
  shared by all servers by default) and review rotation/retention settings.

What it does and does not do
  Reads file sizes/timestamps only, never log contents.
  Reads existing logrotate, rsyslog, syslog-ng, cron and systemd timer settings.
  Reads any cleanup scripts you name as text; they are never executed.
  Does NOT install cron entries, services or timers, change syslog/rotation
  configuration, contact Cribl, or use the network.

Requirements
  Linux, Python 3.6+, standard library only. Keep all package files together.
  Run as an account that can read the log directory and rotation configuration.

Run on each server
    python3 syslog_menu.py

  Prompts:
    Syslog file directory
    File name patterns to measure, e.g. *.log [all non-archive files]
    Output parent directory (must be outside the log directory)
    Optional exported crontabs, raw configuration text (y/N), cleanup scripts
    Optional objectives: maximum file age (hours), size ceiling (GB),
      recovery window (hours), retention disk budget (GB)
    Cribl ingestion rate shared by all servers, MB/sec [2.4]
    Continuous runtime hours [24]
    Seconds between file metadata scans [60]
    Start time, local HH:MM (Enter = start immediately)

  Setup then saves a snapshot of the file inventory, versions and existing
  rotation/cron settings, shows the plan and asks: Start the continuous
  assessment now? [y/N]

  The measurement runs as a background process for this account and keeps
  running after logout. For a combined fleet result, run every server over the
  same period (same start time).

While it runs
    python3 syslog_runner.py status --config <session>/assessment.json
    python3 syslog_runner.py stop   --config <session>/assessment.json
  stop ends early and still writes a report (marked incomplete).
  If the server restarts, the run stops. Progress is saved every 15 minutes;
  run "finish" to write a report from the last checkpoint:
    python3 syslog_runner.py finish --config <session>/assessment.json
  If you answered N at setup, start later with:
    python3 syslog_runner.py start  --config <session>/assessment.json
  Some systems end user processes at logout; if so, run setup inside
  tmux/screen or ask the administrator.

Results
  When the runtime ends the session folder contains:
    syslog_<host>_<time>_final_assessment.json  (for the fleet review)
    syslog_<host>_<time>_final_assessment.txt   (readable summary)
    setup snapshot, continuous measurement and assessment.log
  The summary shows the per-minute fill rate against the shared Cribl rate,
  the peak minute, minutes above the rate, and per-path rotation candidates:
    Rotate at approximately <size> GB OR after <hours> if size is not reached.
  Candidate size = measured path peak MB/sec x maximum file age. It needs a
  file-age objective and is a candidate for review, not a proven setting.
  Files with no growth (e.g. rotated copies) are listed as idle and excluded.
  Evidence gaps are BLOCKING (no measurement, no snapshot, run incomplete) or
  ADVISORY (scan errors, file churn, slow scans, no cleanup script selected),
  which keep the candidate but mark confidence REDUCED.

Fleet result
  Copy each server's final_assessment JSON to one folder and run
  syslog_fleet_review.py (see FLEET_REVIEW_README.txt). It adds all servers'
  rates minute by minute and compares the total with the shared Cribl rate.

Limits
  Rates are per-scan-interval averages; bursts shorter than the interval are
  not visible. Growth is a lower bound: writes hidden by rotation, truncation
  or deletion between scans are not counted. Logical sizes differ from disk
  usage. Settings are recorded at setup time. Read completion and safe
  retention are not proven. Reports with raw configuration or cleanup-script
  text are UNREDACTED; review before sharing. Narrow the directory; never scan
  the filesystem root. Validate any setting in a pilot.
