"""Local system evidence for the syslog assessment. Standard library; read-only; no network."""
import os
import platform
import re
import shutil
import stat
import subprocess
from datetime import datetime, timedelta, timezone

MAX_BYTES = 8 * 1024 * 1024


def stamp():
    return datetime.now(timezone.utc).isoformat()


ISO_PATTERN = re.compile(r'^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})(?:\.(\d{1,6}))?(?:(Z)|([+-])(\d{2}):?(\d{2}))?$')


def parse_iso_datetime(value):
    """datetime.fromisoformat() replacement that also works on Python 3.6.

    Accepts the timestamps this package writes, e.g. 2026-10-27T12:45:12.551026+00:00.
    Returns a timezone-aware datetime when an offset is present, otherwise naive.
    Raises ValueError for anything else.
    """
    match = ISO_PATTERN.match(str(value).strip())
    if not match:
        raise ValueError('Invalid ISO timestamp: %r' % (value,))
    day, clock, fraction, zulu, sign, hours, minutes = match.groups()
    moment = datetime.strptime(day + ' ' + clock, '%Y-%m-%d %H:%M:%S')
    if fraction:
        moment = moment.replace(microsecond=int(fraction.ljust(6, '0')))
    if zulu:
        return moment.replace(tzinfo=timezone.utc)
    if sign:
        offset = timedelta(hours=int(hours), minutes=int(minutes))
        return moment.replace(tzinfo=timezone(offset if sign == '+' else -offset))
    return moment


def read_bytes(path, limit=MAX_BYTES):
    fd = os.open(str(path), os.O_RDONLY | getattr(os, 'O_NONBLOCK', 0))
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode):
            raise ValueError('Not a regular file')
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError('File exceeds %d-byte collection limit' % limit)
    return data


def version_probe(name, arguments):
    executable = shutil.which(name, path='/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/sbin:/usr/local/bin')
    if not executable:
        return {'status': 'unknown', 'version': None, 'reason': 'Not found in standard binary directories'}
    command = [executable] + list(arguments)
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=5, check=False,
                                env=dict(os.environ, LC_ALL='C'))
        output = result.stdout[:16384].decode('utf-8', errors='replace').strip()
        return {'status': 'collected' if result.returncode == 0 and output else 'error',
                'command': command, 'exit_code': result.returncode,
                'version': output.splitlines()[0] if output else None,
                'version_output': output, 'truncated': len(result.stdout) > 16384}
    except (OSError, subprocess.TimeoutExpired):
        return {'status': 'error', 'command': command, 'version': None,
                'reason': 'Version command failed or exceeded five seconds'}


def collect_rotation_timer_status():
    """Query only standard logrotate timer/service properties; never run rotation."""
    executable = shutil.which('systemctl', path='/usr/bin:/bin:/usr/sbin:/sbin')
    if not executable:
        return {'status': 'unavailable', 'reason': 'systemctl not found; cron or another scheduler may be used.'}
    definitions = {
        'logrotate.timer': ('LoadState', 'ActiveState', 'SubState', 'UnitFileState',
                            'LastTriggerUSec', 'NextElapseUSecRealtime', 'NextElapseUSecMonotonic',
                            'RandomizedDelayUSec', 'AccuracyUSec', 'TimersCalendar'),
        'logrotate.service': ('LoadState', 'ActiveState', 'SubState', 'Result',
                              'ExecMainStartTimestamp', 'ExecMainExitTimestamp', 'ExecMainStatus')}
    result = {'status': 'queried', 'collected_utc': stamp(), 'units': {},
              'limitations': ['Only standard logrotate.timer/service are queried; custom/user timers may be missing.',
                             'Trigger/service timestamps do not prove every log file rotated successfully.',
                             'Cron schedules are separate declarations; this does not verify cron job execution.']}
    for unit, properties in definitions.items():
        command = [executable, 'show', unit, '--no-pager', '--property=' + ','.join(properties)]
        try:
            response = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE, timeout=5, check=False,
                                      env=dict(os.environ, LC_ALL='C', SYSTEMD_PAGER='', SYSTEMD_COLORS='0'))
            if response.returncode:
                result['units'][unit] = {'status': 'unavailable', 'exit_code': response.returncode,
                                         'reason': 'Systemd manager/unit query unavailable; verify scheduler separately.'}
                continue
            output = response.stdout[:65536].decode('utf-8', errors='replace')
            values = {k: v for k, separator, v in (line.partition('=') for line in output.splitlines())
                      if separator and k in properties}
            result['units'][unit] = {'status': 'collected' if values.get('LoadState') == 'loaded' else 'not_loaded',
                                     'properties': values, 'output_truncated': len(response.stdout) > 65536}
        except (OSError, subprocess.TimeoutExpired):
            result['units'][unit] = {'status': 'unavailable', 'reason': 'Query failed or exceeded five seconds.'}
    return result


def collect_system_info():
    evidence = {'collected_utc': stamp(), 'os': platform.system(),
                'kernel': platform.release(), 'architecture': platform.machine(),
                'logical_cpus_visible_to_os': os.cpu_count(), 'errors': []}
    try:
        evidence['cpu_affinity_count'] = len(os.sched_getaffinity(0))
    except (AttributeError, OSError):
        evidence['cpu_affinity_count'] = None
    for path, field in [('/etc/os-release', 'os_release'), ('/proc/meminfo', 'memory')]:
        try:
            text = read_bytes(path, 65536).decode('utf-8', errors='replace')
            if field == 'memory':
                evidence['os_visible_memory_bytes'] = int(re.search(r'^MemTotal:\s+(\d+)', text, re.M).group(1)) * 1024
            else:
                evidence[field] = {k: v.strip('"') for k, v in
                                   (line.split('=', 1) for line in text.splitlines() if '=' in line)
                                   if k in ('ID', 'VERSION_ID', 'PRETTY_NAME')}
        except (OSError, ValueError, AttributeError) as exc:
            evidence['errors'].append({'source': path, 'error': str(exc)})
    evidence['software'] = {'rsyslog': version_probe('rsyslogd', ['-v']),
                            'syslog_ng': version_probe('syslog-ng', ['--version']),
                            'logrotate': version_probe('logrotate', ['--version'])}
    evidence['limitations'] = ['Installed versions may differ from running service versions.',
                               'CPU/RAM are OS-visible; container limits and disk performance are not tested.']
    return evidence
